// stock.controller.js
