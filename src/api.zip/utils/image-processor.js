// image-processor.js
