// currency.js
