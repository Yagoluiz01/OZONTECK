// audit.middleware.js
