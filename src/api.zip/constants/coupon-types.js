// coupon-types.js
