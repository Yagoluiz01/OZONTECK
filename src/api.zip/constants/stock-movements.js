// stock-movements.js
