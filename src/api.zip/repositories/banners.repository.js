// banners.repository.js
