// admin-permissions.repository.js
