// products.service.js
