// products.service.js
