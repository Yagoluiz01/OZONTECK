const env = globalThis.env || {};

const SUPABASE_URL =
  env.supabaseUrl ||
  process.env.SUPABASE_URL ||
  process.env.NEXT_PUBLIC_SUPABASE_URL;

const SUPABASE_SERVICE_ROLE_KEY =
  env.supabaseServiceRoleKey ||
  process.env.SUPABASE_SERVICE_ROLE_KEY ||
  process.env.SUPABASE_SERVICE_KEY;

function ensureSupabaseConfig() {
  if (!SUPABASE_URL) {
    throw new Error("SUPABASE_URL não configurado.");
  }

  if (!SUPABASE_SERVICE_ROLE_KEY) {
    throw new Error("SUPABASE_SERVICE_ROLE_KEY não configurado.");
  }
}

function getHeaders(extra = {}) {
  return {
    apikey: SUPABASE_SERVICE_ROLE_KEY,
    Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
    "Content-Type": "application/json",
    Accept: "application/json",
    ...extra,
  };
}

function buildUrl(path) {
  return `${SUPABASE_URL}/rest/v1/${path}`;
}

function toNumber(value, fallback = 0) {
  const num = Number(value);
  return Number.isFinite(num) ? num : fallback;
}

function roundMoney(value) {
  return Number(toNumber(value, 0).toFixed(2));
}

function normalizePercent(value) {
  const percent = toNumber(value, 0);

  if (percent < 0) return 0;
  if (percent > 100) return 100;

  return percent;
}

function getConfiguredNumber(value, fallback = 0) {
  if (value === undefined || value === null || value === "") {
    return fallback;
  }

  const number = Number(value);
  return Number.isFinite(number) ? number : fallback;
}

function resolveShippingCostInPrice(averageShippingCost, shippingPolicy = "customer_paid") {
  const cost = roundMoney(averageShippingCost);
  const policy = String(shippingPolicy || "customer_paid").trim().toLowerCase();

  if (cost <= 0) return 0;

  if (["free_shipping", "frete_gratis", "included", "embutido"].includes(policy)) {
    return cost;
  }

  if (["partial_subsidy", "subsidio_parcial", "partial", "parcial"].includes(policy)) {
    return roundMoney(cost / 2);
  }

  return 0;
}

function getGoalBonusAnalysis(input = {}) {
  const levels = Array.isArray(input.affiliate_goal_levels)
    ? input.affiliate_goal_levels
    : Array.isArray(input.goal_levels)
      ? input.goal_levels
      : [];

  let accumulatedBonus = 0;
  let worstBonusPerSale = roundMoney(
    getConfiguredNumber(
      input.worst_goal_bonus_per_sale ?? input.goal_bonus_per_sale,
      0
    )
  );
  let worstGoalLevelName = input.worst_goal_level_name || null;

  const normalizedLevels = levels
    .filter((level) => level?.is_active !== false)
    .filter((level) => Number(level?.required_conversions || 0) > 0)
    .map((level) => ({
      ...level,
      required_conversions: Math.max(
        1,
        Math.trunc(getConfiguredNumber(level.required_conversions, 1))
      ),
    }))
    .sort((a, b) => {
      const orderDiff = getConfiguredNumber(a.level_order, 0) - getConfiguredNumber(b.level_order, 0);
      if (orderDiff !== 0) return orderDiff;
      return a.required_conversions - b.required_conversions;
    })
    .map((level) => {
      const providedAccumulated = getConfiguredNumber(
        level.accumulated_bonus_amount ?? level.goal_bonus_amount,
        NaN
      );

      if (Number.isFinite(providedAccumulated)) {
        accumulatedBonus = roundMoney(Math.max(providedAccumulated, 0));
      } else if (String(level.bonus_type || "fixed").toLowerCase() !== "manual") {
        accumulatedBonus = roundMoney(
          accumulatedBonus + Math.max(getConfiguredNumber(level.bonus_amount, 0), 0)
        );
      }

      const bonusPerSale = roundMoney(
        getConfiguredNumber(
          level.bonus_per_sale,
          accumulatedBonus / level.required_conversions
        )
      );

      if (bonusPerSale > worstBonusPerSale) {
        worstBonusPerSale = bonusPerSale;
        worstGoalLevelName = level.name || level.level_name || "Meta";
      }

      return {
        ...level,
        accumulated_bonus_amount: accumulatedBonus,
        bonus_per_sale: bonusPerSale,
      };
    });

  return {
    levels: normalizedLevels,
    worstGoalBonusPerSale: roundMoney(worstBonusPerSale),
    worstGoalLevelName,
  };
}

function calculateProductSpecificGoalPlan({
  price,
  baseCost,
  gatewayFeePercent,
  taxPercent,
  affiliateCommissionPercent,
  networkCommissionPercent,
  protectedMarginPercent,
  safetyReservePercent = 15,
  levels = [],
}) {
  const referencePrice = roundMoney(price);
  const reservePercent = Math.min(
    Math.max(normalizePercent(safetyReservePercent), 0),
    50
  );

  const gatewayValue = roundMoney(
    referencePrice * (normalizePercent(gatewayFeePercent) / 100)
  );
  const taxValue = roundMoney(
    referencePrice * (normalizePercent(taxPercent) / 100)
  );
  const directCommissionValue = roundMoney(
    referencePrice * (normalizePercent(affiliateCommissionPercent) / 100)
  );
  const networkCommissionValue = roundMoney(
    referencePrice * (normalizePercent(networkCommissionPercent) / 100)
  );
  const protectedMarginValue = roundMoney(
    referencePrice * (normalizePercent(protectedMarginPercent) / 100)
  );

  const availableBeforeReserve = roundMoney(
    referencePrice -
      roundMoney(baseCost) -
      gatewayValue -
      taxValue -
      directCommissionValue -
      networkCommissionValue -
      protectedMarginValue
  );

  const safetyReserveValue =
    availableBeforeReserve > 0
      ? roundMoney(availableBeforeReserve * (reservePercent / 100))
      : 0;

  const safeContributionPerSale =
    availableBeforeReserve > 0
      ? roundMoney(availableBeforeReserve - safetyReserveValue)
      : 0;

  const normalizedLevels = (Array.isArray(levels) ? levels : []).map(
    (level, index) => {
      const currentRequiredSales = Math.max(
        1,
        Math.trunc(getConfiguredNumber(level?.required_conversions, 1))
      );
      const accumulatedBonus = roundMoney(
        Math.max(
          getConfiguredNumber(
            level?.accumulated_bonus_amount ??
              level?.goal_bonus_amount ??
              level?.bonus_amount,
            0
          ),
          0
        )
      );

      const minimumRequiredSales =
        accumulatedBonus <= 0
          ? currentRequiredSales
          : safeContributionPerSale > 0
            ? Math.max(1, Math.ceil(accumulatedBonus / safeContributionPerSale))
            : null;

      const recommendedRequiredSales =
        minimumRequiredSales === null
          ? null
          : Math.max(currentRequiredSales, minimumRequiredSales);

      const additionalSales =
        recommendedRequiredSales === null
          ? null
          : Math.max(recommendedRequiredSales - currentRequiredSales, 0);

      return {
        id: level?.id || null,
        name: level?.name || level?.level_name || `Meta ${index + 1}`,
        level_order: getConfiguredNumber(level?.level_order, index + 1),
        accumulated_bonus_amount: accumulatedBonus,
        current_required_sales: currentRequiredSales,
        minimum_required_sales: minimumRequiredSales,
        recommended_required_sales: recommendedRequiredSales,
        additional_sales: additionalSales,
        safe_bonus_per_sale:
          recommendedRequiredSales && recommendedRequiredSales > 0
            ? roundMoney(accumulatedBonus / recommendedRequiredSales)
            : 0,
        status:
          minimumRequiredSales === null
            ? "unsupported"
            : currentRequiredSales >= minimumRequiredSales
              ? "already_safe"
              : "increase_sales",
      };
    }
  );

  return {
    mode: "product_specific_sales_target",
    reference_price: referencePrice,
    protected_margin_percent: roundMoney(protectedMarginPercent),
    protected_margin_value: protectedMarginValue,
    base_cost: roundMoney(baseCost),
    gateway_value: gatewayValue,
    tax_value: taxValue,
    direct_commission_value: directCommissionValue,
    network_commission_value: networkCommissionValue,
    available_before_reserve: availableBeforeReserve,
    safety_reserve_percent: roundMoney(reservePercent),
    safety_reserve_value: safetyReserveValue,
    safe_contribution_per_sale: safeContributionPerSale,
    supported: referencePrice > 0 && safeContributionPerSale > 0,
    message:
      referencePrice <= 0
        ? "Informe o preço atual do produto para calcular a meta segura específica."
        : safeContributionPerSale <= 0
          ? "O preço atual não deixa verba segura para financiar bônus sem mexer na margem protegida."
          : "O preço foi mantido. A recomendação aumenta apenas a quantidade de vendas deste produto.",
    levels: normalizedLevels,
  };
}

function normalizePaymentMethod(value) {
  const method = String(value || "pix").trim();

  const allowed = ["pix", "boleto", "credit_card", "debit_card", "wallet"];

  if (!allowed.includes(method)) {
    throw new Error(
      "payment_method inválido. Use: pix, boleto, credit_card, debit_card ou wallet."
    );
  }

  return method;
}

function normalizeReceiptTerm(value) {
  const term = String(value || "instant").trim();

  const allowed = ["instant", "14_days", "30_days"];

  if (!allowed.includes(term)) {
    throw new Error("receipt_term inválido. Use: instant, 14_days ou 30_days.");
  }

  return term;
}

function normalizeInstallments(value) {
  const installments = Math.trunc(toNumber(value, 1));

  if (installments < 1 || installments > 12) {
    throw new Error("installments inválido. Use um número entre 1 e 12.");
  }

  return installments;
}

async function supabaseFetch(path, options = {}) {
  ensureSupabaseConfig();

  const response = await fetch(buildUrl(path), {
    ...options,
    headers: getHeaders(options.headers || {}),
  });

  const text = await response.text();
  let json = null;

  try {
    json = text ? JSON.parse(text) : null;
  } catch {
    json = text;
  }

  if (!response.ok) {
    throw new Error(
      `Erro Supabase [${response.status}] ${
        typeof json === "string" ? json : JSON.stringify(json)
      }`
    );
  }

  return json;
}

function calculatePriceForCommission({
  baseCost,
  goalBonusPerSale = 0,
  gatewayFeePercent,
  taxPercent,
  commissionPercent,
  networkCommissionPercent = 0,
  marginPercent,
}) {
  const fixedCost = roundMoney(baseCost + goalBonusPerSale);
  const variablePercent =
    normalizePercent(gatewayFeePercent) / 100 +
    normalizePercent(taxPercent) / 100 +
    normalizePercent(commissionPercent) / 100 +
    normalizePercent(networkCommissionPercent) / 100 +
    normalizePercent(marginPercent) / 100;

  if (fixedCost <= 0 || variablePercent >= 1) {
    return 0;
  }

  return roundMoney(fixedCost / (1 - variablePercent));
}

function calculateProfitForPrice({
  price,
  baseCost,
  goalBonusPerSale = 0,
  gatewayFeePercent,
  taxPercent,
  commissionPercent,
  networkCommissionPercent = 0,
}) {
  const gatewayValue = roundMoney(
    price * (normalizePercent(gatewayFeePercent) / 100)
  );

  const taxValue = roundMoney(price * (normalizePercent(taxPercent) / 100));

  const commissionValue = roundMoney(
    price * (normalizePercent(commissionPercent) / 100)
  );

  const networkCommissionValue = roundMoney(
    price * (normalizePercent(networkCommissionPercent) / 100)
  );

  const goalBonusValue = roundMoney(goalBonusPerSale);

  const profit = roundMoney(
    price -
      baseCost -
      goalBonusValue -
      gatewayValue -
      taxValue -
      commissionValue -
      networkCommissionValue
  );

  const marginPercent = price > 0 ? roundMoney((profit / price) * 100) : 0;

  return {
    gateway_value: gatewayValue,
    tax_value: taxValue,
    commission_value: commissionValue,
    network_commission_value: networkCommissionValue,
    goal_bonus_value: goalBonusValue,
    affiliate_total_cost: roundMoney(
      commissionValue + networkCommissionValue + goalBonusValue
    ),
    profit,
    margin_percent: marginPercent,
  };
}

function buildRiskStatus({
  suggestedPrice,
  priceWithMaxCommission,
  profitWithMaxCommission,
  marginWithMaxCommissionPercent,
  minimumCompanyMarginPercent,
  maxAffiliateCommissionPercent,
  specialAffiliateCommissionPercent,
}) {
  if (!suggestedPrice || suggestedPrice <= 0) {
    return {
      status: "invalid",
      risk_message:
        "Precificação inválida. Verifique se a soma de taxas, comissão e margem não passou de 100%.",
    };
  }

  if (maxAffiliateCommissionPercent >= 50 && priceWithMaxCommission <= 0) {
    return {
      status: "danger",
      risk_message:
        "A comissão máxima informada é muito alta para a margem atual. Aumente o preço, reduza custos ou reduza comissão.",
    };
  }

  if (profitWithMaxCommission <= 0) {
    return {
      status: "loss",
      risk_message:
        "Com a comissão máxima, este produto pode dar prejuízo. Não aplique comissão especial sem revisar o preço.",
    };
  }

  if (marginWithMaxCommissionPercent < minimumCompanyMarginPercent) {
    return {
      status: "attention",
      risk_message:
        "Com a comissão máxima, a margem da empresa fica abaixo do mínimo definido.",
    };
  }

  if (specialAffiliateCommissionPercent > maxAffiliateCommissionPercent) {
    return {
      status: "attention",
      risk_message:
        "A comissão especial está maior que a comissão máxima segura definida para este produto.",
    };
  }

  return {
    status: "healthy",
    risk_message:
      "Precificação saudável. O produto suporta os custos e a comissão configurada.",
  };
}

function calculatePricing(input) {
  const costPrice = roundMoney(input.cost_price);
  const packagingCost = roundMoney(input.packaging_cost);
  const trafficCost = roundMoney(input.traffic_cost);
  const operationalCost = roundMoney(input.operational_cost);
  const gatewayFeePercent = normalizePercent(input.gateway_fee_percent);
  const taxPercent = normalizePercent(input.tax_percent);
  const otherCosts = roundMoney(input.other_costs);
  const desiredMarginPercent = normalizePercent(input.desired_margin_percent);
  const averageShippingCost = roundMoney(input.average_shipping_cost);
  const shippingPolicy = input.shipping_policy || "customer_paid";
  const shippingCostInPrice = resolveShippingCostInPrice(
    averageShippingCost,
    shippingPolicy
  );

  const goalAnalysis = getGoalBonusAnalysis(input);
  const goalBonusPerSale = goalAnalysis.worstGoalBonusPerSale;

  const affiliateCommissionPercent = normalizePercent(
    getConfiguredNumber(input.affiliate_commission_percent, 10)
  );

  const maxAffiliateCommissionPercent = normalizePercent(
    getConfiguredNumber(input.max_affiliate_commission_percent, 50)
  );

  const specialAffiliateCommissionPercent = normalizePercent(
    getConfiguredNumber(input.special_affiliate_commission_percent, 50)
  );

  const minimumCompanyMarginPercent = normalizePercent(
    getConfiguredNumber(input.minimum_company_margin_percent, 15)
  );

  const commissionScenarioPercent = normalizePercent(
    getConfiguredNumber(input.commission_scenario_percent, 50)
  );

  const networkCommissionPercent = normalizePercent(
    getConfiguredNumber(
      input.network_commission_percent ?? input.recruitment_commission_rate,
      0
    )
  );

  const baseCost = roundMoney(
    costPrice +
      packagingCost +
      trafficCost +
      operationalCost +
      otherCosts +
      shippingCostInPrice
  );

  const basicVariablePercent = gatewayFeePercent / 100 + taxPercent / 100;

  const minimumPrice =
    basicVariablePercent >= 1
      ? 0
      : roundMoney(baseCost / (1 - basicVariablePercent));

  const safeMarginPercent = Math.max(
    desiredMarginPercent,
    minimumCompanyMarginPercent
  );

  const safePrice = calculatePriceForCommission({
    baseCost,
    goalBonusPerSale,
    gatewayFeePercent,
    taxPercent,
    commissionPercent: affiliateCommissionPercent,
    networkCommissionPercent,
    marginPercent: safeMarginPercent,
  });

  const calculatedSuggestedPrice = calculatePriceForCommission({
    baseCost,
    goalBonusPerSale,
    gatewayFeePercent,
    taxPercent,
    commissionPercent: affiliateCommissionPercent,
    networkCommissionPercent,
    marginPercent: desiredMarginPercent,
  });

  const priceWithDefaultCommission = calculatedSuggestedPrice;

  const manualSuggestedPrice = roundMoney(
    input.suggested_price_override ||
      input.manual_suggested_price ||
      input.target_suggested_price ||
      0
  );

  const suggestedPrice =
    manualSuggestedPrice > calculatedSuggestedPrice
      ? manualSuggestedPrice
      : calculatedSuggestedPrice;

  const priceWithMaxCommission = calculatePriceForCommission({
    baseCost,
    goalBonusPerSale,
    gatewayFeePercent,
    taxPercent,
    commissionPercent: maxAffiliateCommissionPercent,
    networkCommissionPercent,
    marginPercent: minimumCompanyMarginPercent,
  });

  const priceWithSpecialCommission = calculatePriceForCommission({
    baseCost,
    goalBonusPerSale,
    gatewayFeePercent,
    taxPercent,
    commissionPercent: specialAffiliateCommissionPercent,
    networkCommissionPercent,
    marginPercent: minimumCompanyMarginPercent,
  });

  const defaultProfitData = calculateProfitForPrice({
    price: priceWithDefaultCommission,
    baseCost,
    goalBonusPerSale,
    gatewayFeePercent,
    taxPercent,
    commissionPercent: affiliateCommissionPercent,
    networkCommissionPercent,
  });

  const maxProfitData = calculateProfitForPrice({
    price: priceWithMaxCommission,
    baseCost,
    goalBonusPerSale,
    gatewayFeePercent,
    taxPercent,
    commissionPercent: maxAffiliateCommissionPercent,
    networkCommissionPercent,
  });

  const specialProfitData = calculateProfitForPrice({
    price: priceWithSpecialCommission,
    baseCost,
    goalBonusPerSale,
    gatewayFeePercent,
    taxPercent,
    commissionPercent: specialAffiliateCommissionPercent,
    networkCommissionPercent,
  });

  const suggestedProfitData = calculateProfitForPrice({
    price: suggestedPrice,
    baseCost,
    goalBonusPerSale,
    gatewayFeePercent,
    taxPercent,
    commissionPercent: affiliateCommissionPercent,
    networkCommissionPercent,
  });

  const currentProductPrice = roundMoney(
    getConfiguredNumber(
      input.current_product_price ?? input.product_price ?? input.currentPrice,
      0
    )
  );

  const productSpecificGoalPlan = calculateProductSpecificGoalPlan({
    price: currentProductPrice > 0 ? currentProductPrice : suggestedPrice,
    baseCost,
    gatewayFeePercent,
    taxPercent,
    affiliateCommissionPercent,
    networkCommissionPercent,
    protectedMarginPercent: safeMarginPercent,
    safetyReservePercent: getConfiguredNumber(
      input.goal_safety_reserve_percent,
      15
    ),
    levels: goalAnalysis.levels,
  });

  const risk = buildRiskStatus({
    suggestedPrice,
    priceWithMaxCommission,
    profitWithMaxCommission: maxProfitData.profit,
    marginWithMaxCommissionPercent: maxProfitData.margin_percent,
    minimumCompanyMarginPercent,
    maxAffiliateCommissionPercent,
    specialAffiliateCommissionPercent,
  });

  return {
    cost_price: roundMoney(costPrice),
    packaging_cost: roundMoney(packagingCost),
    traffic_cost: roundMoney(trafficCost),
    operational_cost: roundMoney(operationalCost),
    gateway_fee_percent: roundMoney(gatewayFeePercent),
    tax_percent: roundMoney(taxPercent),
    other_costs: roundMoney(otherCosts),
    average_shipping_cost: roundMoney(averageShippingCost),
    shipping_cost_in_price: roundMoney(shippingCostInPrice),
    shipping_policy: shippingPolicy,
    desired_margin_percent: roundMoney(desiredMarginPercent),

    affiliate_commission_percent: roundMoney(affiliateCommissionPercent),
    max_affiliate_commission_percent: roundMoney(maxAffiliateCommissionPercent),
    special_affiliate_commission_percent: roundMoney(
      specialAffiliateCommissionPercent
    ),
    minimum_company_margin_percent: roundMoney(minimumCompanyMarginPercent),
    commission_scenario_percent: roundMoney(commissionScenarioPercent),
    network_commission_percent: roundMoney(networkCommissionPercent),
    goal_bonus_per_sale: roundMoney(goalBonusPerSale),
    worst_goal_bonus_per_sale: roundMoney(goalBonusPerSale),
    worst_goal_level_name: goalAnalysis.worstGoalLevelName,

    cost_total: roundMoney(baseCost),
    minimum_price: roundMoney(minimumPrice),
    safe_price: roundMoney(safePrice),
    suggested_price: roundMoney(suggestedPrice),
    unit_profit: roundMoney(suggestedProfitData.profit),
    real_margin_percent: roundMoney(suggestedProfitData.margin_percent),
    direct_commission_value: roundMoney(suggestedProfitData.commission_value),
    network_commission_value: roundMoney(
      suggestedProfitData.network_commission_value
    ),
    goal_bonus_value: roundMoney(suggestedProfitData.goal_bonus_value),
    affiliate_total_cost: roundMoney(suggestedProfitData.affiliate_total_cost),

    price_with_default_commission: roundMoney(priceWithDefaultCommission),
    price_with_max_commission: roundMoney(priceWithMaxCommission),
    price_with_special_commission: roundMoney(priceWithSpecialCommission),

    profit_with_default_commission: roundMoney(defaultProfitData.profit),
    profit_with_max_commission: roundMoney(maxProfitData.profit),
    profit_with_special_commission: roundMoney(specialProfitData.profit),

    margin_with_default_commission_percent: roundMoney(
      defaultProfitData.margin_percent
    ),
    margin_with_max_commission_percent: roundMoney(maxProfitData.margin_percent),
    margin_with_special_commission_percent: roundMoney(
      specialProfitData.margin_percent
    ),

    goal_analysis: {
      levels: goalAnalysis.levels,
      worst_bonus_per_sale: roundMoney(goalBonusPerSale),
      worst_goal_level_name: goalAnalysis.worstGoalLevelName,
      product_specific_plan: productSpecificGoalPlan,
    },

    status: risk.status,
    risk_message: risk.risk_message,
  };
}

async function getProductById(productId) {
  const rows = await supabaseFetch(
    `products?select=id,name,sku,price&id=eq.${productId}&limit=1`,
    { method: "GET" }
  );

  return rows?.[0] || null;
}

async function listActiveAffiliateLevelsForProductGoals() {
  const rows = await supabaseFetch(
    "affiliate_levels?select=*&is_active=eq.true&order=level_order.asc",
    { method: "GET" }
  );

  let accumulatedBonus = 0;

  return (Array.isArray(rows) ? rows : [])
    .filter((level) => Number(level?.required_conversions || 0) > 0)
    .map((level, index) => {
      const bonusType = String(level?.bonus_type || "fixed").toLowerCase();

      if (bonusType !== "manual") {
        accumulatedBonus = roundMoney(
          accumulatedBonus + Math.max(toNumber(level?.bonus_amount, 0), 0)
        );
      }

      const requiredConversions = Math.max(
        1,
        Math.trunc(toNumber(level?.required_conversions, 1))
      );

      return {
        ...level,
        level_order: toNumber(level?.level_order, index + 1),
        required_conversions: requiredConversions,
        accumulated_bonus_amount: accumulatedBonus,
        bonus_per_sale: roundMoney(accumulatedBonus / requiredConversions),
      };
    });
}

function normalizeProductGoalTargetRow(row = {}, level = null) {
  return {
    ...row,
    required_units: Math.max(1, Math.trunc(toNumber(row.required_units, 1))),
    global_required_conversions_snapshot: Math.max(
      1,
      Math.trunc(toNumber(row.global_required_conversions_snapshot, 1))
    ),
    accumulated_bonus_amount: roundMoney(row.accumulated_bonus_amount),
    safe_contribution_per_unit: roundMoney(row.safe_contribution_per_unit),
    reference_price: roundMoney(row.reference_price),
    protected_margin_percent: roundMoney(row.protected_margin_percent),
    safety_reserve_percent: roundMoney(row.safety_reserve_percent),
    level,
  };
}

async function createPricingHistory({
  productId,
  pricingId = null,
  pricingData,
  eventType,
  currentProductPrice = 0,
  notes = null,
}) {
  const body = {
    product_id: productId,
    pricing_id: pricingId,
    event_type: eventType,
    current_product_price: roundMoney(currentProductPrice),

    cost_price: roundMoney(pricingData.cost_price),
    packaging_cost: roundMoney(pricingData.packaging_cost),
    traffic_cost: roundMoney(pricingData.traffic_cost),
    operational_cost: roundMoney(pricingData.operational_cost),
    gateway_fee_percent: roundMoney(pricingData.gateway_fee_percent),
    tax_percent: roundMoney(pricingData.tax_percent),
    other_costs: roundMoney(pricingData.other_costs),
    average_shipping_cost: roundMoney(pricingData.average_shipping_cost),
    shipping_cost_in_price: roundMoney(pricingData.shipping_cost_in_price),
    shipping_policy: pricingData.shipping_policy || "customer_paid",
    desired_margin_percent: roundMoney(pricingData.desired_margin_percent),

    affiliate_commission_percent: roundMoney(
      pricingData.affiliate_commission_percent
    ),
    max_affiliate_commission_percent: roundMoney(
      pricingData.max_affiliate_commission_percent
    ),
    special_affiliate_commission_percent: roundMoney(
      pricingData.special_affiliate_commission_percent
    ),
    minimum_company_margin_percent: roundMoney(
      pricingData.minimum_company_margin_percent
    ),
    commission_scenario_percent: roundMoney(
      pricingData.commission_scenario_percent
    ),
    network_commission_percent: roundMoney(
      pricingData.network_commission_percent
    ),
    goal_bonus_per_sale: roundMoney(pricingData.goal_bonus_per_sale),
    worst_goal_bonus_per_sale: roundMoney(
      pricingData.worst_goal_bonus_per_sale
    ),
    worst_goal_level_name: pricingData.worst_goal_level_name || null,

    cost_total: roundMoney(pricingData.cost_total),
    minimum_price: roundMoney(pricingData.minimum_price),
    safe_price: roundMoney(pricingData.safe_price),
    suggested_price: roundMoney(pricingData.suggested_price),
    unit_profit: roundMoney(pricingData.unit_profit),
    real_margin_percent: roundMoney(pricingData.real_margin_percent),
    direct_commission_value: roundMoney(pricingData.direct_commission_value),
    network_commission_value: roundMoney(
      pricingData.network_commission_value
    ),
    goal_bonus_value: roundMoney(pricingData.goal_bonus_value),
    affiliate_total_cost: roundMoney(pricingData.affiliate_total_cost),
    goal_analysis:
      pricingData.goal_analysis && typeof pricingData.goal_analysis === "object"
        ? pricingData.goal_analysis
        : {},

    price_with_default_commission: roundMoney(
      pricingData.price_with_default_commission
    ),
    price_with_max_commission: roundMoney(pricingData.price_with_max_commission),
    price_with_special_commission: roundMoney(
      pricingData.price_with_special_commission
    ),

    profit_with_default_commission: roundMoney(
      pricingData.profit_with_default_commission
    ),
    profit_with_max_commission: roundMoney(
      pricingData.profit_with_max_commission
    ),
    profit_with_special_commission: roundMoney(
      pricingData.profit_with_special_commission
    ),

    margin_with_default_commission_percent: roundMoney(
      pricingData.margin_with_default_commission_percent
    ),
    margin_with_max_commission_percent: roundMoney(
      pricingData.margin_with_max_commission_percent
    ),
    margin_with_special_commission_percent: roundMoney(
      pricingData.margin_with_special_commission_percent
    ),

    status: pricingData.status || "pending",
    risk_message: pricingData.risk_message || null,
    notes: notes || null,
  };

  const created = await supabaseFetch("product_pricing_history", {
    method: "POST",
    headers: {
      Prefer: "return=representation",
    },
    body: JSON.stringify(body),
  });

  return created?.[0] || null;
}

export async function listPaymentFeeRules() {
  return await supabaseFetch(
    "payment_fee_rules?select=*&provider=eq.mercado_pago&is_active=eq.true&order=payment_method.asc,receipt_term.asc,installments.asc",
    { method: "GET" }
  );
}

export async function simulatePaymentFee(payload = {}) {
  const amount = roundMoney(payload.amount || payload.gross_amount);

  if (!amount || amount <= 0) {
    throw new Error("amount é obrigatório e precisa ser maior que zero.");
  }

  const paymentMethod = normalizePaymentMethod(
    payload.payment_method || payload.paymentMethod
  );

  const receiptTerm = normalizeReceiptTerm(
    payload.receipt_term || payload.receiptTerm
  );

  const installments = normalizeInstallments(payload.installments || 1);

  let rows = await supabaseFetch(
    `payment_fee_rules?select=*&provider=eq.mercado_pago&payment_method=eq.${encodeURIComponent(
      paymentMethod
    )}&receipt_term=eq.${encodeURIComponent(
      receiptTerm
    )}&installments=eq.${installments}&is_active=eq.true&limit=1`,
    { method: "GET" }
  );

  let rule = rows?.[0] || null;

  if (!rule && paymentMethod !== "credit_card") {
    rows = await supabaseFetch(
      `payment_fee_rules?select=*&provider=eq.mercado_pago&payment_method=eq.${encodeURIComponent(
        paymentMethod
      )}&installments=eq.1&is_active=eq.true&limit=1`,
      { method: "GET" }
    );

    rule = rows?.[0] || null;
  }

  if (!rule && paymentMethod === "credit_card" && installments > 1) {
    rows = await supabaseFetch(
      `payment_fee_rules?select=*&provider=eq.mercado_pago&payment_method=eq.credit_card&receipt_term=eq.instant&installments=eq.${installments}&is_active=eq.true&limit=1`,
      { method: "GET" }
    );

    rule = rows?.[0] || null;
  }

  if (!rule) {
    throw new Error(
      "Nenhuma taxa ativa encontrada para esta forma de pagamento."
    );
  }

  const percentFee = normalizePercent(rule.percent_fee);
  const fixedFee = roundMoney(rule.fixed_fee);
  const feeAmount = roundMoney(amount * (percentFee / 100) + fixedFee);
  const netAmount = roundMoney(amount - feeAmount);
  const effectivePercent = amount > 0 ? roundMoney((feeAmount / amount) * 100) : 0;

  return {
    provider: rule.provider,
    rule_id: rule.id,

    payment_method: rule.payment_method,
    receipt_term: rule.receipt_term,
    installments: rule.installments,

    gross_amount: amount,
    percent_fee: roundMoney(percentFee),
    fixed_fee: fixedFee,
    fee_amount: feeAmount,
    net_amount: netAmount,
    effective_percent: effectivePercent,

    notes: rule.notes || null,
  };
}

export async function listPricingRecords() {
  return await supabaseFetch(
    "product_pricing?select=*,products(id,name,sku,price)&order=updated_at.desc",
    { method: "GET" }
  );
}

export async function getPricingByProductId(productId) {
  const rows = await supabaseFetch(
    `product_pricing?select=*,products(id,name,sku,price)&product_id=eq.${productId}&limit=1`,
    { method: "GET" }
  );

  return rows?.[0] || null;
}

export async function getPricingHistoryByProductId(productId) {
  return await supabaseFetch(
    `product_pricing_history?select=*&product_id=eq.${productId}&order=created_at.desc`,
    { method: "GET" }
  );
}

export async function calculateProductPricing(payload) {
  const productId = payload.product_id || payload.productId;

  if (!productId) {
    throw new Error("product_id é obrigatório.");
  }

  const pricing = calculatePricing(payload);

  return {
    product_id: productId,
    ...pricing,
    notes: payload.notes || null,
  };
}

export async function saveProductPricing(payload) {
  const productId = payload.product_id || payload.productId;

  if (!productId) {
    throw new Error("product_id é obrigatório.");
  }

  const calculated = await calculateProductPricing(payload);
  const existing = await getPricingByProductId(productId);
  const product = await getProductById(productId);

  let saved = null;

  if (existing?.id) {
    const updated = await supabaseFetch(`product_pricing?id=eq.${existing.id}`, {
      method: "PATCH",
      headers: {
        Prefer: "return=representation",
      },
      body: JSON.stringify({
        ...calculated,
        notes: payload.notes || null,
      }),
    });

    saved = updated?.[0] || null;
  } else {
    const created = await supabaseFetch("product_pricing", {
      method: "POST",
      headers: {
        Prefer: "return=representation",
      },
      body: JSON.stringify({
        ...calculated,
        notes: payload.notes || null,
      }),
    });

    saved = created?.[0] || null;
  }

  if (saved) {
    await createPricingHistory({
      productId,
      pricingId: saved.id,
      pricingData: saved,
      eventType: "save_pricing",
      currentProductPrice: product?.price || 0,
      notes: payload.notes || null,
    });
  }

  return saved;
}

export async function getProductGoalTargets(productId) {
  const normalizedProductId = String(productId || "").trim();

  if (!normalizedProductId) {
    throw new Error("productId é obrigatório.");
  }

  const [rows, levels] = await Promise.all([
    supabaseFetch(
      `affiliate_product_goal_targets?select=*&product_id=eq.${encodeURIComponent(
        normalizedProductId
      )}&is_active=eq.true`,
      { method: "GET" }
    ),
    supabaseFetch(
      "affiliate_levels?select=id,name,level_order,required_conversions,bonus_amount,bonus_type,is_active",
      { method: "GET" }
    ),
  ]);

  const levelMap = new Map(
    (Array.isArray(levels) ? levels : []).map((level) => [String(level.id), level])
  );

  return (Array.isArray(rows) ? rows : [])
    .map((row) =>
      normalizeProductGoalTargetRow(
        row,
        levelMap.get(String(row.affiliate_level_id || "")) || null
      )
    )
    .sort((a, b) => {
      const orderA = toNumber(a?.level?.level_order, 9999);
      const orderB = toNumber(b?.level?.level_order, 9999);
      return orderA - orderB;
    });
}

export async function applyProductGoalTargets(productId, { actorId = null } = {}) {
  const normalizedProductId = String(productId || "").trim();

  if (!normalizedProductId) {
    throw new Error("productId é obrigatório.");
  }

  const [pricing, product, activeLevels] = await Promise.all([
    getPricingByProductId(normalizedProductId),
    getProductById(normalizedProductId),
    listActiveAffiliateLevelsForProductGoals(),
  ]);

  if (!product?.id) {
    throw new Error("Produto não encontrado.");
  }

  if (!pricing?.id) {
    throw new Error(
      "Salve a precificação deste produto antes de aplicar a meta segura específica."
    );
  }

  if (!activeLevels.length) {
    throw new Error("Nenhuma meta ativa foi encontrada para aplicar neste produto.");
  }

  const calculated = await calculateProductPricing({
    ...pricing,
    product_id: normalizedProductId,
    current_product_price: product.price || pricing.suggested_price || 0,
    affiliate_goal_levels: activeLevels,
    goal_levels: activeLevels,
  });

  const plan = calculated?.goal_analysis?.product_specific_plan || null;
  const planLevels = Array.isArray(plan?.levels) ? plan.levels : [];

  if (!plan?.supported || Number(plan?.safe_contribution_per_sale || 0) <= 0) {
    throw new Error(
      plan?.message ||
        "O produto não possui contribuição segura suficiente para aplicar uma meta específica."
    );
  }

  const now = new Date().toISOString();
  const rowsToUpsert = planLevels
    .filter((level) => level?.id && Number(level?.recommended_required_sales || 0) > 0)
    .map((level) => ({
      product_id: normalizedProductId,
      affiliate_level_id: level.id,
      required_units: Math.max(
        1,
        Math.trunc(Number(level.recommended_required_sales || 1))
      ),
      global_required_conversions_snapshot: Math.max(
        1,
        Math.trunc(Number(level.current_required_sales || 1))
      ),
      accumulated_bonus_amount: roundMoney(level.accumulated_bonus_amount),
      safe_contribution_per_unit: roundMoney(plan.safe_contribution_per_sale),
      reference_price: roundMoney(plan.reference_price),
      protected_margin_percent: roundMoney(plan.protected_margin_percent),
      safety_reserve_percent: roundMoney(plan.safety_reserve_percent),
      calculation_snapshot: {
        source: "pricing_product_specific_goal",
        product_name: product.name || null,
        product_sku: product.sku || null,
        level_name: level.name || null,
        level_order: level.level_order || null,
        minimum_required_sales: level.minimum_required_sales || null,
        additional_sales: level.additional_sales || 0,
        safe_bonus_per_sale: roundMoney(level.safe_bonus_per_sale),
        plan_status: level.status || null,
      },
      is_active: true,
      created_by: actorId ? String(actorId) : null,
      applied_at: now,
      updated_at: now,
    }));

  if (!rowsToUpsert.length) {
    throw new Error("Nenhuma meta segura válida foi gerada para este produto.");
  }

  await supabaseFetch(
    "affiliate_product_goal_targets?on_conflict=product_id,affiliate_level_id",
    {
      method: "POST",
      headers: {
        Prefer: "resolution=merge-duplicates,return=representation",
      },
      body: JSON.stringify(rowsToUpsert),
    }
  );

  const activeLevelIds = new Set(rowsToUpsert.map((row) => row.affiliate_level_id));
  const existingRows = await supabaseFetch(
    `affiliate_product_goal_targets?select=id,affiliate_level_id,is_active&product_id=eq.${encodeURIComponent(
      normalizedProductId
    )}`,
    { method: "GET" }
  );

  const staleRows = (Array.isArray(existingRows) ? existingRows : []).filter(
    (row) => row?.is_active !== false && !activeLevelIds.has(row?.affiliate_level_id)
  );

  for (const row of staleRows) {
    await supabaseFetch(`affiliate_product_goal_targets?id=eq.${row.id}`, {
      method: "PATCH",
      headers: {
        Prefer: "return=minimal",
      },
      body: JSON.stringify({
        is_active: false,
        updated_at: now,
      }),
    });
  }

  const targets = await getProductGoalTargets(normalizedProductId);

  return {
    product,
    pricing_id: pricing.id,
    plan,
    targets,
  };
}

export async function applySuggestedPriceToProduct(productId) {
  if (!productId) {
    throw new Error("productId é obrigatório.");
  }

  const pricing = await getPricingByProductId(productId);

  if (!pricing) {
    throw new Error("Precificação não encontrada para este produto.");
  }

  const suggestedPrice = roundMoney(pricing.suggested_price);

  if (!suggestedPrice || suggestedPrice <= 0) {
    throw new Error(
      "Preço sugerido inválido. Calcule e salve a precificação antes de aplicar."
    );
  }

  if (
    pricing.status === "loss" ||
    pricing.status === "danger" ||
    pricing.status === "invalid"
  ) {
    throw new Error(
      pricing.risk_message ||
        "Este produto está com risco financeiro. Ajuste a precificação antes de aplicar."
    );
  }

  const updatedProduct = await supabaseFetch(`products?id=eq.${productId}`, {
    method: "PATCH",
    headers: {
      Prefer: "return=representation",
    },
    body: JSON.stringify({
      price: suggestedPrice,
    }),
  });

  const product = updatedProduct?.[0] || null;

  await createPricingHistory({
    productId,
    pricingId: pricing.id,
    pricingData: pricing,
    eventType: "apply_price",
    currentProductPrice: product?.price || suggestedPrice,
    notes: pricing.notes || null,
  });

  return {
    pricing,
    product,
  };
}

export async function listProductsForPricing(search = "") {
  const filters = ["select=id,name,sku,price"];

  if (search) {
    filters.push(`name=ilike.*${encodeURIComponent(search)}*`);
  }

  filters.push("order=created_at.desc");

  return await supabaseFetch(`products?${filters.join("&")}`, {
    method: "GET",
  });
}

export default {
  listPaymentFeeRules,
  simulatePaymentFee,
  listPricingRecords,
  getPricingByProductId,
  getPricingHistoryByProductId,
  calculateProductPricing,
  saveProductPricing,
  getProductGoalTargets,
  applyProductGoalTargets,
  applySuggestedPriceToProduct,
  listProductsForPricing,
};