// stock.service.js
