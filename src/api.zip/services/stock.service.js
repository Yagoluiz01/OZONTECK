// stock.service.js
