import { askAI } from "./core/ai.core.js";

export async function sendAiMessage({
  message,
  history = [],
  user,
}) {
  return await askAI({
    message,
    history,
    user,
  });
}