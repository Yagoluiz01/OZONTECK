import { resolveAction } from "../router/action.router.js";

import {
  getContexts,
  applyPermissions,
  loadKnowledge,
} from "../manager/index.js";

import { executeTools } from "../tools/execute.tools.js";

import { dispatchAction } from "../dispatcher/action.dispatcher.js";

import { buildSystemPrompt } from "../prompts/system.prompt.js";

import { askDeepSeek } from "../providers/deepseek.provider.js";

export async function askAI({
  message,
  history = [],
  user,
}) {
  const contexts = await getContexts({
    message,
    user,
});

  const allowedContexts = applyPermissions(
    contexts,
    user
  );

  const knowledge = await loadKnowledge(
    allowedContexts
  );

  const toolData = await executeTools(
    allowedContexts,
    knowledge
  );

  const action = resolveAction(message);

  let actionResult = null;

  if (action) {
    actionResult = await dispatchAction({
      action,
      knowledge: toolData,
      message,
    });
  }

  const systemPrompt = buildSystemPrompt({
    knowledge: toolData,
    actionResult,
    user,
  });

  return await askDeepSeek({
    message,
    history,
    systemPrompt,
  });
}