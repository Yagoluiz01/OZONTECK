import {
  notifyOrderCreatedPending,
  notifyOrderPaid,
  notifyOrderPaymentPending,
  notifyOrderPaymentFailed
} from "../services/orderNotification.service.js";
import {
  notifyAffiliateCreated,
  notifyAffiliateCommissionCreated
} from "../services/affiliateNotification.service.js";
import { sendPushToAffiliate } from "../services/affiliatePush.service.js";
import { getPublicAffiliateStorefront } from "../services/affiliatePortal.service.js";
import { rankHomeProducts, rankStorefrontProducts } from "../services/productRanking.service.js";
import express from "express";
import bcrypt from "bcryptjs";
import { requireAdminAuth } from "../middlewares/auth.middleware.js";
import { requireMasterAdmin } from "../middlewares/masterAdmin.middleware.js";
import crypto from "crypto";
import { env } from "../config/env.js";
import {
  calculateShippingWithMelhorEnvio,
  buildMelhorEnvioAuthorizeUrl
} from "../services/melhorEnvio.service.js";
import { generateAutomaticShippingLabel } from "../services/shipping.service.js";
import { processPaidOrder } from "../jobs/processPaidOrder.js";
import {
  applyMercadoPagoPaymentTransition,
  claimOrderShippingLabelGeneration,
  createStoreOrderAtomic,
  ensureOrderStockReserved,
  releaseOrderStock,
} from "../services/orderStock.service.js";
import { syncAffiliateCommissionLifecycleForOrder } from "../services/affiliateCommissionLifecycle.service.js";
import { createIntegrationOAuthState } from "../services/oauthState.service.js";
import { createActivationOfferForPaidOrder } from "../services/customerActivation.service.js";
import {
  getCustomerOrderPushPublicKey,
  saveCustomerOrderPushSubscription,
  sendCustomerOrderPushForPaymentApproved,
  sendCustomerOrderPushForTracking
} from "../services/customerOrderPush.service.js";

const router = express.Router();

const HOME_PRODUCTS_SERVER_CACHE_TTL_MS = 60 * 1000;
const HOME_PRODUCTS_SERVER_CACHE_STALE_MS = 15 * 60 * 1000;
const HOME_PRODUCTS_SERVER_CACHE_LIMIT = 24;

let homeProductsServerCache = {
  createdAt: 0,
  products: [],
};
let homeProductsLoadPromise = null;

function getMarketingPixelSupabaseHeaders() {
  return {
    apikey: env.supabaseServiceRoleKey,
    Authorization: `Bearer ${env.supabaseServiceRoleKey}`,
    "Content-Type": "application/json",
    Accept: "application/json",
  };
}

function normalizeMarketingPixel(row = {}) {
  return {
    id: row.id,
    provider: String(row.provider || "").trim(),
    name: String(row.name || "").trim(),
    pixelId: String(row.pixel_id || "").trim(),
    isActive: Boolean(row.is_active),
    enabledEvents: Array.isArray(row.enabled_events) ? row.enabled_events : [],
    pageRules: Array.isArray(row.page_rules) ? row.page_rules : ["all"],
    extraConfig:
      row.extra_config && typeof row.extra_config === "object"
        ? row.extra_config
        : {},
  };
}

router.get("/marketing/pixels", async (req, res) => {
  try {
    const url = new URL(`${env.supabaseUrl}/rest/v1/marketing_pixels`);

    url.searchParams.set("is_active", "eq.true");
    url.searchParams.set(
      "select",
      "id,provider,name,pixel_id,is_active,enabled_events,page_rules,extra_config,created_at,updated_at"
    );
    url.searchParams.set("order", "created_at.asc");

    const response = await fetch(url.toString(), {
      method: "GET",
      headers: getMarketingPixelSupabaseHeaders(),
    });

    const data = await response.json().catch(() => []);

    if (!response.ok) {
      console.error("ERRO AO BUSCAR PIXELS DE MARKETING:", {
        status: response.status,
        message: data?.message || data?.error || null,
      });

      return res.status(500).json({
        success: false,
        message: "Erro ao buscar pixels de marketing",
        pixels: [],
      });
    }

    const pixels = Array.isArray(data)
      ? data
          .map(normalizeMarketingPixel)
          .filter((pixel) => pixel.provider && pixel.pixelId && pixel.isActive)
      : [];

    return res.json({
      success: true,
      pixels,
    });
  } catch (error) {
    console.error("ERRO GERAL AO BUSCAR PIXELS DE MARKETING:", error);

    return res.status(500).json({
      success: false,
      message: "Erro ao buscar pixels de marketing",
      pixels: [],
    });
  }
});


async function safeCustomerOrderPush(label, order, callback) {
  try {
    return await callback(order);
  } catch (error) {
    console.error(`ERRO AO ENVIAR PUSH PARA CLIENTE (${label}):`, {
      orderId: order?.id || null,
      orderNumber: order?.order_number || null,
      error: error?.message || String(error),
    });

    return {
      sent: 0,
      failed: 1,
      skipped: false,
      error: error?.message || "Erro ao enviar push para cliente",
    };
  }
}


async function safeAffiliatePush(label, affiliateId, notification) {
  try {
    if (!affiliateId) {
      return {
        sent: 0,
        failed: 0,
        skipped: true,
        reason: "missing_affiliate_id",
      };
    }

    return await sendPushToAffiliate(affiliateId, notification);
  } catch (error) {
    console.error(`ERRO AO ENVIAR PUSH DE AFILIADO (${label}):`, error);
    return {
      sent: 0,
      failed: 1,
      skipped: false,
      error: error?.message || "Erro ao enviar push de afiliado",
    };
  }
}

function formatMoneyBR(value) {
  const number = Number(value || 0);

  return number.toLocaleString("pt-BR", {
    style: "currency",
    currency: "BRL",
  });
}

function roundMoney(value) {
  const number = Number(value || 0);

  if (!Number.isFinite(number)) {
    return 0;
  }

  return Number(number.toFixed(2));
}

function normalizeItemQuantity(value) {
  const quantity = Number(value ?? 1);

  if (!Number.isInteger(quantity) || quantity < 1 || quantity > 999) {
    const error = new Error(
      "Quantidade inválida. Use um número inteiro entre 1 e 999."
    );
    error.status = 400;
    throw error;
  }

  return quantity;
}

function isMissingDatabaseColumnError(payload) {
  const text = JSON.stringify(payload || {}).toLowerCase();

  return (
    text.includes("column") &&
    (text.includes("does not exist") ||
      text.includes("could not find") ||
      text.includes("schema cache"))
  );
}

function getMercadoPagoFinancialData(payment = {}) {
  const transactionAmount = roundMoney(payment?.transaction_amount || 0);
  const netReceivedAmount = roundMoney(
    payment?.transaction_details?.net_received_amount || 0
  );
  const feeDetails = Array.isArray(payment?.fee_details)
    ? payment.fee_details
    : [];
  const feeDetailsAmount = roundMoney(
    feeDetails.reduce(
      (sum, item) => sum + Math.abs(Number(item?.amount || 0) || 0),
      0
    )
  );
  const calculatedFee =
    transactionAmount > 0 && netReceivedAmount > 0
      ? roundMoney(Math.max(transactionAmount - netReceivedAmount, 0))
      : 0;
  const gatewayFee = calculatedFee > 0 ? calculatedFee : feeDetailsAmount;
  const resolvedNetAmount =
    netReceivedAmount > 0
      ? netReceivedAmount
      : roundMoney(Math.max(transactionAmount - gatewayFee, 0));

  return {
    gatewayFee,
    netAmount: resolvedNetAmount,
    paymentMethodId: String(payment?.payment_method_id || "").trim(),
    paymentTypeId: String(payment?.payment_type_id || "").trim(),
    installments: Math.max(1, Math.trunc(Number(payment?.installments || 1) || 1)),
  };
}

function resolveEmbeddedShippingCost(averageShippingCost, shippingPolicy) {
  const cost = roundMoney(averageShippingCost);
  const policy = String(shippingPolicy || "customer_paid").trim().toLowerCase();

  if (cost <= 0) return 0;
  if (["free_shipping", "frete_gratis", "included", "embutido"].includes(policy)) {
    return cost;
  }
  if (["partial_subsidy", "subsidio_parcial", "partial", "parcial"].includes(policy)) {
    return roundMoney(cost / 2);
  }

  return 0;
}

function buildOrderCostSnapshot(items = [], pricingMap = new Map()) {
  const enrichedItems = items.map((item) => {
    const productId = String(item?.product?.id || item?.product_id || "").trim();
    const pricing = pricingMap.get(productId) || {};
    const quantity = normalizeItemQuantity(item.quantity);
    const unitProductCost = roundMoney(pricing.cost_price);
    const unitPackagingCost = roundMoney(pricing.packaging_cost);
    const unitTrafficCost = roundMoney(pricing.traffic_cost);
    const unitOperationalCost = roundMoney(pricing.operational_cost);
    const unitOtherCost = roundMoney(pricing.other_costs);
    const unitEmbeddedShippingCost = resolveEmbeddedShippingCost(
      pricing.average_shipping_cost,
      pricing.shipping_policy
    );
    const unitTotalCost = roundMoney(
      unitProductCost +
        unitPackagingCost +
        unitTrafficCost +
        unitOperationalCost +
        unitOtherCost
    );

    return {
      ...item,
      costSnapshot: {
        unitProductCost,
        unitPackagingCost,
        unitTrafficCost,
        unitOperationalCost,
        unitOtherCost,
        unitEmbeddedShippingCost,
        unitTotalCost,
        totalCost: roundMoney(unitTotalCost * quantity),
        pricingId: pricing.id || null,
        pricingUpdatedAt: pricing.updated_at || null,
      },
    };
  });

  const totals = enrichedItems.reduce(
    (acc, item) => {
      const quantity = item.quantity;
      const snapshot = item.costSnapshot;

      acc.productCost += snapshot.unitProductCost * quantity;
      acc.packagingCost += snapshot.unitPackagingCost * quantity;
      acc.trafficCost += snapshot.unitTrafficCost * quantity;
      acc.operationalCost += snapshot.unitOperationalCost * quantity;
      acc.otherCost += snapshot.unitOtherCost * quantity;
      acc.embeddedShippingEstimate += snapshot.unitEmbeddedShippingCost * quantity;
      acc.totalCost += snapshot.totalCost;
      if (!snapshot.pricingId) acc.itemsWithoutPricing += 1;
      return acc;
    },
    {
      productCost: 0,
      packagingCost: 0,
      trafficCost: 0,
      operationalCost: 0,
      otherCost: 0,
      embeddedShippingEstimate: 0,
      totalCost: 0,
      itemsWithoutPricing: 0,
    }
  );

  Object.keys(totals).forEach((key) => {
    if (key !== "itemsWithoutPricing") totals[key] = roundMoney(totals[key]);
  });

  return { items: enrichedItems, totals };
}

function normalizePercentValue(value, fallback = 0) {
  const number = Number(value);

  if (!Number.isFinite(number) || number < 0) {
    return roundMoney(fallback);
  }

  if (number > 100) {
    return 100;
  }

  return roundMoney(number);
}

function getCommissionBaseFromOrder(order = {}) {
  const subtotal = Number(order?.subtotal || 0) || 0;
  const discount = Number(order?.discount_amount || 0) || 0;

  return roundMoney(Math.max(subtotal - discount, 0));
}

async function fetchProductPricingMap(productIds = []) {
  const uniqueProductIds = [
    ...new Set(
      productIds
        .map((id) => String(id || "").trim())
        .filter(Boolean)
    ),
  ];

  if (!uniqueProductIds.length) {
    return new Map();
  }

  try {
    const url = new URL(`${env.supabaseUrl}/rest/v1/product_pricing`);
    url.searchParams.set("select", "*");
    url.searchParams.set("product_id", `in.(${uniqueProductIds.join(",")})`);

    const response = await fetch(url.toString(), {
      method: "GET",
      headers: {
        apikey: env.supabaseServiceRoleKey,
        Authorization: `Bearer ${env.supabaseServiceRoleKey}`,
        "Content-Type": "application/json",
        Accept: "application/json",
      },
    });

    const data = await response.json().catch(() => []);

    if (!response.ok || !Array.isArray(data)) {
      console.warn("PRECIFICAÇÃO DO PRODUTO NÃO CARREGADA PARA COMISSÃO:", data);
      return new Map();
    }

    return new Map(
      data
        .filter((row) => row?.product_id)
        .map((row) => [String(row.product_id), row])
    );
  } catch (error) {
    console.error("ERRO AO BUSCAR PRECIFICAÇÃO PARA COMISSÃO:", error);
    return new Map();
  }
}

function calculateCommissionPolicyFromCartItems({
  items = [],
  discountAmount = 0,
  fallbackSellerRate = 0,
  fallbackRecruitmentRate = 0,
  pricingMap = new Map(),
} = {}) {
  const subtotal = roundMoney(
    items.reduce((sum, item) => sum + Number(item.totalPrice || item.total_price || 0), 0)
  );
  const safeDiscount = roundMoney(Math.max(Number(discountAmount || 0) || 0, 0));
  const commissionBase = roundMoney(Math.max(subtotal - safeDiscount, 0));
  const discountRatio = subtotal > 0 ? Math.min(safeDiscount / subtotal, 1) : 0;

  let sellerCommissionAmount = 0;
  let recruitmentCommissionAmount = 0;

  for (const item of items) {
    const productId = String(item?.product?.id || item?.product_id || "").trim();
    const pricing = pricingMap.get(productId) || {};
    const itemTotal = roundMoney(Number(item.totalPrice || item.total_price || 0) || 0);
    const itemBase = roundMoney(Math.max(itemTotal - itemTotal * discountRatio, 0));

    const sellerRate = normalizePercentValue(
      pricing.affiliate_commission_percent ?? fallbackSellerRate,
      fallbackSellerRate
    );
    const recruitmentRate = normalizePercentValue(
      pricing.network_commission_percent ?? fallbackRecruitmentRate,
      fallbackRecruitmentRate
    );

    sellerCommissionAmount += roundMoney((itemBase * sellerRate) / 100);
    recruitmentCommissionAmount += roundMoney((itemBase * recruitmentRate) / 100);
  }

  sellerCommissionAmount = roundMoney(sellerCommissionAmount);
  recruitmentCommissionAmount = roundMoney(recruitmentCommissionAmount);

  const sellerRate = commissionBase > 0
    ? roundMoney((sellerCommissionAmount / commissionBase) * 100)
    : normalizePercentValue(fallbackSellerRate);

  const recruitmentRate = commissionBase > 0
    ? roundMoney((recruitmentCommissionAmount / commissionBase) * 100)
    : normalizePercentValue(fallbackRecruitmentRate);

  return {
    commissionBase,
    sellerRate,
    sellerCommissionAmount,
    recruitmentRate,
    recruitmentCommissionAmount,
  };
}

async function calculateCommissionPolicyForOrder(order = {}, sellerAffiliate = null) {
  const fallbackSellerRate = normalizePercentValue(
    order.affiliate_commission_rate || sellerAffiliate?.commission_rate || 0
  );
  const fallbackRecruitmentRate = normalizePercentValue(
    getRecruitmentCommissionRate(sellerAffiliate || {})
  );

  let items = [];

  try {
    if (order?.id) {
      items = await findOrderItems(order.id);
    }
  } catch (error) {
    console.error("ERRO AO BUSCAR ITENS PARA COMISSÃO DO PEDIDO:", error);
  }

  if (!items.length) {
    const commissionBase = getCommissionBaseFromOrder(order);
    const sellerCommissionAmount = roundMoney((commissionBase * fallbackSellerRate) / 100);
    const recruitmentCommissionAmount = roundMoney((commissionBase * fallbackRecruitmentRate) / 100);

    return {
      commissionBase,
      sellerRate: fallbackSellerRate,
      sellerCommissionAmount,
      recruitmentRate: fallbackRecruitmentRate,
      recruitmentCommissionAmount,
    };
  }

  const pricingMap = await fetchProductPricingMap(items.map((item) => item.product_id));

  return calculateCommissionPolicyFromCartItems({
    items,
    discountAmount: order.discount_amount || 0,
    fallbackSellerRate,
    fallbackRecruitmentRate,
    pricingMap,
  });
}


function slugify(text) {
  return String(text || "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

function toNumber(value, fallback = 0) {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

function toBoolean(value, fallback = false) {
  if (value === true || value === 1) return true;
  if (value === false || value === 0) return false;
  if (value === null || value === undefined || value === "") return fallback;

  const text = String(value).trim().toLowerCase();

  if (["true", "1", "yes", "sim", "on", "active", "ativo"].includes(text)) {
    return true;
  }

  if (["false", "0", "no", "nao", "não", "off", "inactive", "inativo"].includes(text)) {
    return false;
  }

  return fallback;
}

function onlyDigits(value) {
  return String(value || "").replace(/\D/g, "");
}


function normalizeAffiliateCode(value) {
  return String(value || "")
    .trim()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toUpperCase()
    .replace(/[^A-Z0-9_-]/g, "");
}


function cleanText(value) {
  return String(value || "").trim();
}

function normalizeEmail(value) {
  return cleanText(value).toLowerCase();
}

function isValidEmail(value) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalizeEmail(value));
}

async function findAffiliateApplicationByEmail(email) {
  const cleanEmail = normalizeEmail(email);

  if (!cleanEmail) {
    return null;
  }

  const url = new URL(`${env.supabaseUrl}/rest/v1/affiliate_applications`);
  url.searchParams.set("select", "id,email,status,created_at");
  url.searchParams.set("email", `eq.${cleanEmail}`);
  url.searchParams.set("status", "eq.pending");
  url.searchParams.set("limit", "1");

  const response = await fetch(url.toString(), {
    method: "GET",
    headers: {
      apikey: env.supabaseServiceRoleKey,
      Authorization: `Bearer ${env.supabaseServiceRoleKey}`,
      "Content-Type": "application/json",
      Accept: "application/json",
    },
  });

  const data = await response.json().catch(() => []);

  if (!response.ok || !Array.isArray(data) || !data[0]?.id) {
    return null;
  }

  return data[0];
}

function buildAffiliateCodeBase(fullName, email) {
  const fromName = normalizeAffiliateCode(
    String(fullName || "")
      .trim()
      .split(/\s+/)
      .filter(Boolean)[0] || ""
  );

  if (fromName && fromName.length >= 3) {
    return fromName.slice(0, 8);
  }

  const fromEmail = normalizeAffiliateCode(String(email || "").split("@")[0]);

  if (fromEmail && fromEmail.length >= 3) {
    return fromEmail.slice(0, 8);
  }

  return "OZT";
}

async function affiliateCodeExists({ refCode, couponCode }) {
  const cleanRefCode = normalizeAffiliateCode(refCode);
  const cleanCouponCode = normalizeAffiliateCode(couponCode);

  if (!cleanRefCode && !cleanCouponCode) {
    return false;
  }

  const headers = {
    apikey: env.supabaseServiceRoleKey,
    Authorization: `Bearer ${env.supabaseServiceRoleKey}`,
    "Content-Type": "application/json",
    Accept: "application/json",
  };

  if (cleanRefCode) {
    const affiliatesRefUrl = new URL(`${env.supabaseUrl}/rest/v1/affiliates`);
    affiliatesRefUrl.searchParams.set("select", "id");
    affiliatesRefUrl.searchParams.set("ref_code", `eq.${cleanRefCode}`);
    affiliatesRefUrl.searchParams.set("limit", "1");

    const affiliatesRefResponse = await fetch(affiliatesRefUrl.toString(), {
      method: "GET",
      headers,
    });

    const affiliatesRefData = await affiliatesRefResponse.json().catch(() => []);

    if (
      affiliatesRefResponse.ok &&
      Array.isArray(affiliatesRefData) &&
      affiliatesRefData[0]?.id
    ) {
      return true;
    }

    const applicationsRefUrl = new URL(
      `${env.supabaseUrl}/rest/v1/affiliate_applications`
    );
    applicationsRefUrl.searchParams.set("select", "id");
    applicationsRefUrl.searchParams.set("desired_ref_code", `eq.${cleanRefCode}`);
    applicationsRefUrl.searchParams.set("status", "eq.pending");
    applicationsRefUrl.searchParams.set("limit", "1");

    const applicationsRefResponse = await fetch(applicationsRefUrl.toString(), {
      method: "GET",
      headers,
    });

    const applicationsRefData = await applicationsRefResponse
      .json()
      .catch(() => []);

    if (
      applicationsRefResponse.ok &&
      Array.isArray(applicationsRefData) &&
      applicationsRefData[0]?.id
    ) {
      return true;
    }
  }

  if (cleanCouponCode) {
    const affiliatesCouponUrl = new URL(`${env.supabaseUrl}/rest/v1/affiliates`);
    affiliatesCouponUrl.searchParams.set("select", "id");
    affiliatesCouponUrl.searchParams.set("coupon_code", `eq.${cleanCouponCode}`);
    affiliatesCouponUrl.searchParams.set("limit", "1");

    const affiliatesCouponResponse = await fetch(
      affiliatesCouponUrl.toString(),
      {
        method: "GET",
        headers,
      }
    );

    const affiliatesCouponData = await affiliatesCouponResponse
      .json()
      .catch(() => []);

    if (
      affiliatesCouponResponse.ok &&
      Array.isArray(affiliatesCouponData) &&
      affiliatesCouponData[0]?.id
    ) {
      return true;
    }

    const applicationsCouponUrl = new URL(
      `${env.supabaseUrl}/rest/v1/affiliate_applications`
    );
    applicationsCouponUrl.searchParams.set("select", "id");
    applicationsCouponUrl.searchParams.set(
      "desired_coupon_code",
      `eq.${cleanCouponCode}`
    );
    applicationsCouponUrl.searchParams.set("status", "eq.pending");
    applicationsCouponUrl.searchParams.set("limit", "1");

    const applicationsCouponResponse = await fetch(
      applicationsCouponUrl.toString(),
      {
        method: "GET",
        headers,
      }
    );

    const applicationsCouponData = await applicationsCouponResponse
      .json()
      .catch(() => []);

    if (
      applicationsCouponResponse.ok &&
      Array.isArray(applicationsCouponData) &&
      applicationsCouponData[0]?.id
    ) {
      return true;
    }
  }

  return false;
}

async function generateUniqueAffiliateCodes({ fullName, email }) {
  const base = buildAffiliateCodeBase(fullName, email);

  for (let attempt = 0; attempt < 30; attempt += 1) {
    const randomNumber = crypto.randomInt(1000, 9999);
    const refCode = normalizeAffiliateCode(`${base}${randomNumber}`);
    const couponCode = refCode;

    const exists = await affiliateCodeExists({
      refCode,
      couponCode,
    });

    if (!exists) {
      return {
        refCode,
        couponCode,
      };
    }
  }

  const fallback = normalizeAffiliateCode(`OZT${Date.now().toString().slice(-8)}`);

  return {
    refCode: fallback,
    couponCode: fallback,
  };
}

async function createAffiliateApplication(input = {}) {
  const fullName = cleanText(input.full_name || input.fullName || input.name);
  const email = normalizeEmail(input.email);
  const phone = cleanText(input.phone || input.telefone);
  const pixKey = cleanText(input.pix_key || input.pixKey);
  const password = String(input.password || "").trim();
  const passwordConfirm = String(
    input.password_confirm || input.passwordConfirm || ""
  ).trim();

  if (!fullName) {
    throw new Error("Nome completo é obrigatório.");
  }

  if (fullName.length < 3) {
    throw new Error("Informe um nome completo válido.");
  }

  if (!email) {
    throw new Error("E-mail é obrigatório.");
  }

  if (!isValidEmail(email)) {
    throw new Error("Informe um e-mail válido.");
  }

  if (!phone) {
    throw new Error("Telefone é obrigatório.");
  }

  if (!pixKey) {
    throw new Error("Chave Pix é obrigatória.");
  }

  if (!password) {
    throw new Error("Senha é obrigatória.");
  }

  if (password.length < 8) {
    throw new Error("A senha precisa ter pelo menos 8 caracteres.");
  }

  if (!/[A-Z]/.test(password)) {
    throw new Error("A senha precisa ter pelo menos uma letra maiúscula.");
  }

  if (!/[a-z]/.test(password)) {
    throw new Error("A senha precisa ter pelo menos uma letra minúscula.");
  }

  if (!/[0-9]/.test(password)) {
    throw new Error("A senha precisa ter pelo menos um número.");
  }

  if (passwordConfirm && password !== passwordConfirm) {
    throw new Error("As senhas não conferem.");
  }

  const recruiterRefCode = normalizeAffiliateCode(
    input.recruiter_ref_code ||
      input.recruiterRefCode ||
      input.recruiter ||
      input.recrutador ||
      input.indicado_por
  );

  const existingPending = await findAffiliateApplicationByEmail(email);

  if (existingPending) {
    return {
      alreadyExists: true,
      application: existingPending,
    };
  }

  let recruiterAffiliate = null;

  if (recruiterRefCode) {
    recruiterAffiliate = await findActiveAffiliateByRef(recruiterRefCode);

    if (!recruiterAffiliate?.id) {
      throw new Error("Código do afiliado recrutador não encontrado ou inativo.");
    }

    if (normalizeEmail(recruiterAffiliate.email) === email) {
      throw new Error("Você não pode usar seu próprio código como recrutador.");
    }
  }

  const [passwordHash, generatedCodes] = await Promise.all([
    bcrypt.hash(password, 10),
    generateUniqueAffiliateCodes({
      fullName,
      email,
    }),
  ]);

  const payload = {
    full_name: fullName,
    email,
    phone,
    pix_key: pixKey,
    password_hash: passwordHash,
    instagram: null,
    message: null,
    desired_ref_code: generatedCodes.refCode,
    desired_coupon_code: generatedCodes.couponCode,
    recruiter_ref_code: recruiterAffiliate?.ref_code || recruiterRefCode || null,
    recruiter_affiliate_id: recruiterAffiliate?.id || null,
    status: "pending",
    admin_notes: null,
  };

  const response = await fetch(
    `${env.supabaseUrl}/rest/v1/affiliate_applications`,
    {
      method: "POST",
      headers: {
        apikey: env.supabaseServiceRoleKey,
        Authorization: `Bearer ${env.supabaseServiceRoleKey}`,
        "Content-Type": "application/json",
        Accept: "application/json",
        Prefer: "return=representation",
      },
      body: JSON.stringify(payload),
    }
  );

  const data = await response.json().catch(() => []);

    if (!response.ok || !Array.isArray(data) || !data[0]?.id) {
    console.error("ERRO SUPABASE AFFILIATE APPLICATION:", data);
    throw new Error("Erro ao salvar solicitação de afiliado.");
  }

  const application = data[0];

  setTimeout(() => {
    notifyAffiliateCreated(application).catch((notificationError) => {
      console.error(
        "ERRO AO ENVIAR NOTIFICAÇÃO DE SOLICITAÇÃO DE AFILIADO:",
        notificationError
      );
    });
  }, 0);

  return {
    alreadyExists: false,
    application,
  };
}

async function findActiveAffiliateByRef(refCode) {
  const cleanRefCode = normalizeAffiliateCode(refCode);

  if (!cleanRefCode) {
    return null;
  }

  const url = new URL(`${env.supabaseUrl}/rest/v1/affiliates`);
  url.searchParams.set("select", "id,email,full_name,ref_code,coupon_code,status,commission_rate,recruitment_commission_rate");
  url.searchParams.set("ref_code", `eq.${cleanRefCode}`);
  url.searchParams.set("status", "eq.active");
  url.searchParams.set("limit", "1");

  const response = await fetch(url.toString(), {
    method: "GET",
    headers: {
      apikey: env.supabaseServiceRoleKey,
      Authorization: `Bearer ${env.supabaseServiceRoleKey}`,
      "Content-Type": "application/json",
      Accept: "application/json"
    }
  });

  const data = await response.json().catch(() => []);

  if (!response.ok || !Array.isArray(data) || !data[0]?.id) {
    return null;
  }

  return data[0];
}

async function createActivationOfferSafely(order, source = "unknown") {
  try {
    const result = await createActivationOfferForPaidOrder(order);

    console.log("CUSTOMER ACTIVATION OFFER RESULT:", {
      source,
      orderId: order?.id || null,
      orderNumber: order?.order_number || null,
      created: result?.created || false,
      skipped: result?.skipped || false,
      reason: result?.reason || "",
    });

    return result;
  } catch (error) {
    console.error("ERRO AO CRIAR CONDIÇÃO DE ATIVAÇÃO:", {
      source,
      orderId: order?.id || null,
      orderNumber: order?.order_number || null,
      error: error?.message || String(error),
    });

    return {
      success: false,
      created: false,
      skipped: false,
      reason: "activation_offer_unexpected_error",
      error: error?.message || String(error),
    };
  }
}


function getRecruitmentCommissionRate(affiliate = {}) {
  const configured =
    affiliate.recruitment_commission_rate ||
    process.env.AFFILIATE_RECRUITMENT_COMMISSION_RATE ||
    process.env.RECRUITMENT_COMMISSION_RATE ||
    5;

  const rate = Number(configured);

  if (!Number.isFinite(rate) || rate <= 0) {
    return 5;
  }

  if (rate > 100) {
    return 100;
  }

  return Number(rate.toFixed(2));
}



async function findAffiliateById(affiliateId) {
  const id = String(affiliateId || "").trim();

  if (!id) {
    return null;
  }

  const url = new URL(`${env.supabaseUrl}/rest/v1/affiliates`);
  url.searchParams.set("select", "*");
  url.searchParams.set("id", `eq.${id}`);
  url.searchParams.set("limit", "1");

  const response = await fetch(url.toString(), {
    method: "GET",
    headers: {
      apikey: env.supabaseServiceRoleKey,
      Authorization: `Bearer ${env.supabaseServiceRoleKey}`,
      "Content-Type": "application/json",
      Accept: "application/json"
    }
  });

  const data = await response.json().catch(() => []);

  if (!response.ok || !Array.isArray(data) || !data[0]?.id) {
    return null;
  }

  return data[0];
}

async function createRecruitmentBonusForPaidOrder(order, recruitedAffiliate, commissionPolicy = null) {
  if (!order?.id || !recruitedAffiliate?.id) {
    return {
      created: false,
      skipped: true,
      reason: "missing_recruited_affiliate"
    };
  }

  const recruiterAffiliateId = String(
    recruitedAffiliate.recruiter_affiliate_id || ""
  ).trim();

  if (!recruiterAffiliateId) {
    return {
      created: false,
      skipped: true,
      reason: "affiliate_without_recruiter"
    };
  }

  if (recruiterAffiliateId === String(recruitedAffiliate.id)) {
    return {
      created: false,
      skipped: true,
      reason: "self_recruitment_blocked"
    };
  }

  const recruiterAffiliate = await findAffiliateById(recruiterAffiliateId);

  if (!recruiterAffiliate?.id) {
    return {
      created: false,
      skipped: true,
      reason: "recruiter_not_found"
    };
  }

  if (String(recruiterAffiliate.status || "").toLowerCase() !== "active") {
    return {
      created: false,
      skipped: true,
      reason: "recruiter_not_active"
    };
  }

  const safeOrderTotal = roundMoney(
    Number(commissionPolicy?.commissionBase ?? getCommissionBaseFromOrder(order)) || 0
  );

  if (safeOrderTotal <= 0) {
    return {
      created: false,
      skipped: true,
      reason: "invalid_order_total_for_recruitment_commission"
    };
  }

  const recruitmentCommissionRate = normalizePercentValue(
    commissionPolicy?.recruitmentRate ?? getRecruitmentCommissionRate(recruiterAffiliate)
  );

  const recruitmentCommissionAmount = roundMoney(
    commissionPolicy?.recruitmentCommissionAmount ??
      ((safeOrderTotal * recruitmentCommissionRate) / 100)
  );

  if (recruitmentCommissionRate <= 0 || recruitmentCommissionAmount <= 0) {
    return {
      created: false,
      skipped: true,
      reason: "invalid_recruitment_commission"
    };
  }

  const checkUrl = new URL(`${env.supabaseUrl}/rest/v1/affiliate_conversions`);
  checkUrl.searchParams.set("select", "id");
  checkUrl.searchParams.set("order_id", `eq.${order.id}`);
  checkUrl.searchParams.set("affiliate_id", `eq.${recruiterAffiliate.id}`);
  checkUrl.searchParams.set("conversion_type", "eq.recruitment_bonus");
  checkUrl.searchParams.set("recruited_affiliate_id", `eq.${recruitedAffiliate.id}`);
  checkUrl.searchParams.set("limit", "1");

  const checkResponse = await fetch(checkUrl.toString(), {
    method: "GET",
    headers: {
      apikey: env.supabaseServiceRoleKey,
      Authorization: `Bearer ${env.supabaseServiceRoleKey}`,
      "Content-Type": "application/json",
      Accept: "application/json"
    }
  });

  const checkData = await checkResponse.json().catch(() => []);

  if (checkResponse.ok && Array.isArray(checkData) && checkData[0]?.id) {
    return {
      created: false,
      skipped: true,
      reason: "recruitment_commission_already_exists_for_this_order",
      conversionId: checkData[0].id
    };
  }

  const payload = {
    affiliate_id: recruiterAffiliate.id,
    order_id: order.id,
    customer_id: null,
    ref_code: recruiterAffiliate.ref_code || "",
    coupon_code: recruiterAffiliate.coupon_code || "",
    order_total: safeOrderTotal,
    commission_rate: recruitmentCommissionRate,
    commission_amount: recruitmentCommissionAmount,
    conversion_type: "recruitment_bonus",
    recruited_affiliate_id: recruitedAffiliate.id,
    seller_affiliate_id: recruitedAffiliate.id,
    recruitment_commission_rate: recruitmentCommissionRate,
    recruitment_bonus_amount: recruitmentCommissionAmount,
    status: "approved",
    approved_at: new Date().toISOString(),
    released_at: null,
    metadata: {
      source: "affiliate_recruitment_commission",
      release_policy: "after_delivery",
      order_id: order.id,
      order_number: order.order_number || "",
      order_total: safeOrderTotal,
      commission_base: safeOrderTotal,
      subtotal: roundMoney(order.subtotal || 0),
      shipping_amount: roundMoney(order.shipping_amount || 0),
      discount_amount: roundMoney(order.discount_amount || 0),
      payment_total: roundMoney(order.total_amount || 0),
      freight_excluded_from_commission: true,
      recruitment_commission_rate: recruitmentCommissionRate,
      recruitment_commission_amount: recruitmentCommissionAmount,
      recruiter_affiliate_id: recruiterAffiliate.id,
      recruited_affiliate_id: recruitedAffiliate.id,
      recruited_affiliate_name: recruitedAffiliate.full_name || "",
      recruited_affiliate_email: recruitedAffiliate.email || "",
      recruited_affiliate_ref_code: recruitedAffiliate.ref_code || ""
    },
    notes: `Comissão de recrutamento de ${recruitmentCommissionRate}% criada automaticamente pelo pedido ${order.order_number || order.id}, venda feita pelo afiliado ${recruitedAffiliate.full_name || recruitedAffiliate.ref_code || recruitedAffiliate.id}. Frete não incluído na base da comissão.`
  };

  const createResponse = await fetch(`${env.supabaseUrl}/rest/v1/affiliate_conversions`, {
    method: "POST",
    headers: {
      apikey: env.supabaseServiceRoleKey,
      Authorization: `Bearer ${env.supabaseServiceRoleKey}`,
      "Content-Type": "application/json",
      Prefer: "return=representation"
    },
    body: JSON.stringify(payload)
  });

  const createData = await createResponse.json().catch(() => []);

  if (!createResponse.ok || !Array.isArray(createData) || !createData[0]?.id) {
    console.error("ERRO SUPABASE RECRUITMENT COMMISSION:", createData);
    throw new Error("Erro ao criar comissão de recrutamento do afiliado");
  }

  const conversion = createData[0];

  try {
    await notifyAffiliateCommissionCreated(recruiterAffiliate, {
      ...conversion,
      order_number: order.order_number || order.id
    });
  } catch (notificationError) {
    console.error(
      "ERRO AO ENVIAR NOTIFICAÇÃO DE COMISSÃO DE RECRUTAMENTO:",
      notificationError
    );
  }

  await safeAffiliatePush("recruitment_commission_created", recruiterAffiliate.id, {
    title: "🎁 Comissão de rede",
    body: `Você ganhou ${formatMoneyBR(recruitmentCommissionAmount)} pela venda de ${recruitedAffiliate.full_name || "um afiliado da sua rede"}.`,
    url: "/pages-html/afiliado-painel.html",
    data: {
      type: "recruitment_commission_created",
      affiliate_id: recruiterAffiliate.id,
      recruited_affiliate_id: recruitedAffiliate.id,
      seller_affiliate_id: recruitedAffiliate.id,
      conversion_id: conversion.id || null,
      order_id: order.id,
      order_number: order.order_number || null,
      order_total: safeOrderTotal,
      commission_rate: recruitmentCommissionRate,
      commission_amount: recruitmentCommissionAmount,
    },
  });

  return {
    created: true,
    skipped: false,
    conversion
  };
}

async function createAffiliateConversionForPaidOrder(order) {
  if (!order?.id || !order?.affiliate_id) {
    return {
      created: false,
      skipped: true,
      reason: "order_without_affiliate"
    };
  }

  const sellerAffiliate = await findAffiliateById(order.affiliate_id);
  const commissionPolicy = await calculateCommissionPolicyForOrder(order, sellerAffiliate);
  const orderTotal = commissionPolicy.commissionBase;

  const checkUrl = new URL(`${env.supabaseUrl}/rest/v1/affiliate_conversions`);
  checkUrl.searchParams.set("select", "id");
  checkUrl.searchParams.set("order_id", `eq.${order.id}`);
  checkUrl.searchParams.set("conversion_type", "eq.sale_commission");
  checkUrl.searchParams.set("limit", "1");

  const checkResponse = await fetch(checkUrl.toString(), {
    method: "GET",
    headers: {
      apikey: env.supabaseServiceRoleKey,
      Authorization: `Bearer ${env.supabaseServiceRoleKey}`,
      "Content-Type": "application/json",
      Accept: "application/json"
    }
  });

  const checkData = await checkResponse.json().catch(() => []);

  if (checkResponse.ok && Array.isArray(checkData) && checkData[0]?.id) {
    const recruitmentBonusResult = await createRecruitmentBonusForPaidOrder(
      order,
      sellerAffiliate,
      commissionPolicy
    );

    return {
      created: false,
      skipped: true,
      reason: "sale_commission_already_exists",
      conversionId: checkData[0].id,
      recruitmentBonus: recruitmentBonusResult
    };
  }

  const commissionRate = normalizePercentValue(commissionPolicy.sellerRate);
  const commissionAmount = roundMoney(commissionPolicy.sellerCommissionAmount);

  if (commissionRate <= 0 || commissionAmount <= 0) {
    return {
      created: false,
      skipped: true,
      reason: "invalid_commission"
    };
  }

  const payload = {
    affiliate_id: order.affiliate_id,
    order_id: order.id,
    customer_id: null,
    ref_code: order.affiliate_ref_code || sellerAffiliate?.ref_code || "",
    coupon_code: order.affiliate_coupon_code || sellerAffiliate?.coupon_code || "",
    order_total: orderTotal,
    commission_rate: commissionRate,
    commission_amount: commissionAmount,
    conversion_type: "sale_commission",
    status: "approved",
    approved_at: new Date().toISOString(),
    released_at: null,
    metadata: {
      source: "affiliate_sale_commission",
      release_policy: "after_delivery",
      commission_base: orderTotal,
      subtotal: roundMoney(order.subtotal || 0),
      shipping_amount: roundMoney(order.shipping_amount || 0),
      discount_amount: roundMoney(order.discount_amount || 0),
      payment_total: roundMoney(order.total_amount || 0),
      freight_excluded_from_commission: true,
    },
    notes: `Comissão criada automaticamente pelo pedido ${order.order_number || order.id}. Frete não incluído na base da comissão.`
  };

  const createResponse = await fetch(`${env.supabaseUrl}/rest/v1/affiliate_conversions`, {
    method: "POST",
    headers: {
      apikey: env.supabaseServiceRoleKey,
      Authorization: `Bearer ${env.supabaseServiceRoleKey}`,
      "Content-Type": "application/json",
      Prefer: "return=representation"
    },
    body: JSON.stringify(payload)
  });

  const createData = await createResponse.json().catch(() => []);

  if (!createResponse.ok || !Array.isArray(createData) || !createData[0]?.id) {
    throw new Error("Erro ao criar comissão do afiliado");
  }

  const conversion = createData[0];

  try {
    if (sellerAffiliate?.email) {
      await notifyAffiliateCommissionCreated(sellerAffiliate, {
        ...conversion,
        order_number: order.order_number || order.id
      });
    } else {
      console.warn("NOTIFICAÇÃO DE COMISSÃO DO AFILIADO IGNORADA: afiliado não encontrado", {
        affiliateId: order.affiliate_id,
        orderId: order.id,
        orderNumber: order.order_number
      });
    }
  } catch (notificationError) {
    console.error(
      "ERRO AO ENVIAR NOTIFICAÇÃO DE COMISSÃO DO AFILIADO:",
      notificationError
    );
  }

  await safeAffiliatePush("sale_commission_created", order.affiliate_id, {
    title: "🚀 Venda",
    body: `Pedido ${order.order_number || order.id}: comissão de ${formatMoneyBR(commissionAmount)} gerada.`,
    url: "/pages-html/afiliado-painel.html",
    data: {
      type: "sale_commission_created",
      affiliate_id: order.affiliate_id,
      conversion_id: conversion.id || null,
      order_id: order.id,
      order_number: order.order_number || null,
      commission_amount: commissionAmount,
    },
  });

  const recruitmentBonusResult = await createRecruitmentBonusForPaidOrder(
    order,
    sellerAffiliate,
    commissionPolicy
  );

  return {
    created: true,
    skipped: false,
    conversion,
    recruitmentBonus: recruitmentBonusResult
  };
}


function getPublicProductIdentity(product = {}) {
  return String(product.id || product.slug || product.sku || product.name || "").trim();
}

function getPublicVariantGroup(product = {}) {
  return String(product.variant_group || product.variantGroup || "").trim();
}

function isPublicKitProduct(product = {}) {
  const variantType = String(product.variant_type || product.variantType || "").trim().toLowerCase();

  if (variantType === "kit") {
    return true;
  }

  const text = String([
    product.name,
    product.slug,
    product.sku,
    product.variant_label,
    product.variantLabel
  ].filter(Boolean).join(" "))
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase();

  return /\b(kit|combo|conjunto|completo)\b/.test(text);
}

function filterKitChildrenForStorefront(products = []) {
  const groups = new Map();

  products.forEach((product) => {
    const group = getPublicVariantGroup(product);
    if (!group) return;

    const key = group
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .toLowerCase()
      .trim();

    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(product);
  });

  const visibleKitByGroup = new Map();

  groups.forEach((members, group) => {
    const kitProduct = members.find(isPublicKitProduct);

    if (kitProduct) {
      visibleKitByGroup.set(group, getPublicProductIdentity(kitProduct));
    }
  });

  return products.filter((product) => {
    const group = getPublicVariantGroup(product);

    if (!group) {
      return true;
    }

    const key = group
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .toLowerCase()
      .trim();
    const kitIdentity = visibleKitByGroup.get(key);

    if (!kitIdentity) {
      return true;
    }

    return getPublicProductIdentity(product) === kitIdentity;
  });
}

function normalizeProduct(product) {
  const id = String(product?.id || "").trim();
  const name = String(product?.name || "").trim();
  const sku = String(product?.sku || "").trim();
  const slug = String(product?.slug || sku || slugify(name || id)).trim();

  return {
    id,
    sku,
    slug,
    name,
    category: String(product?.category || "").trim(),
    shortDescription: String(
      product?.short_description ||
        product?.shortDescription ||
        product?.description ||
        ""
    ).trim(),
    description: String(
      product?.description || product?.short_description || ""
    ).trim(),
    imageUrl: String(product?.image_url || product?.image || "").trim(),
    imageUrl2: String(
      product?.image_url_2 ||
        product?.image2 ||
        product?.image_url ||
        product?.image ||
        ""
    ).trim(),

    // Vídeo do produto usado na página de detalhes.
    // Mantemos snake_case e camelCase para compatibilidade com o frontend.
    video_url: String(product?.video_url || product?.videoUrl || "").trim(),
    videoUrl: String(product?.video_url || product?.videoUrl || "").trim(),
    video_poster_url: String(
      product?.video_poster_url || product?.videoPosterUrl || ""
    ).trim(),
    videoPosterUrl: String(
      product?.video_poster_url || product?.videoPosterUrl || ""
    ).trim(),

    price: toNumber(product?.price, 0),
    compareAtPrice: toNumber(product?.compare_at_price, 0),
    compare_at_price: toNumber(product?.compare_at_price, 0),
    stockQuantity: toNumber(product?.stock_quantity, 0),
    status: String(product?.status || "").trim().toLowerCase(),
    is_active: toBoolean(product?.is_active, String(product?.status || "").trim().toLowerCase() === "active"),
    isActive: toBoolean(product?.is_active, String(product?.status || "").trim().toLowerCase() === "active"),
    featured: toBoolean(product?.featured ?? product?.is_featured, false),
    show_home: toBoolean(product?.show_home ?? product?.show_on_home ?? product?.showHome ?? product?.showOnHome, false),
    show_on_home: toBoolean(product?.show_on_home ?? product?.show_home ?? product?.showOnHome ?? product?.showHome, false),
    showHome: toBoolean(product?.show_home ?? product?.show_on_home ?? product?.showHome ?? product?.showOnHome, false),
    showOnHome: toBoolean(product?.show_on_home ?? product?.show_home ?? product?.showOnHome ?? product?.showHome, false),
    variant_group: String(product?.variant_group || product?.variantGroup || "").trim(),
    variantGroup: String(product?.variant_group || product?.variantGroup || "").trim(),
    variant_type: String(product?.variant_type || product?.variantType || "").trim(),
    variantType: String(product?.variant_type || product?.variantType || "").trim(),
    variant_label: String(product?.variant_label || product?.variantLabel || "").trim(),
    variantLabel: String(product?.variant_label || product?.variantLabel || "").trim(),
    variant_order: toNumber(product?.variant_order ?? product?.variantOrder, 0),
    variantOrder: toNumber(product?.variant_order ?? product?.variantOrder, 0),
    weightKg: toNumber(product?.weight_kg, 0),
    heightCm: toNumber(product?.height_cm, 0),
    widthCm: toNumber(product?.width_cm, 0),
    lengthCm: toNumber(product?.length_cm, 0),

    // Dados de parcelamento/precificação usados pela loja.
    // Mantemos snake_case para compatibilidade com o banco/Supabase
    // e camelCase para evitar quebrar qualquer frontend que use esse padrão.
    installment_count: toNumber(product?.installment_count, 12),
    installmentCount: toNumber(product?.installment_count, 12),
    installment_value:
      product?.installment_value === null || product?.installment_value === undefined
        ? null
        : toNumber(product?.installment_value, 0),
    installmentValue:
      product?.installment_value === null || product?.installment_value === undefined
        ? null
        : toNumber(product?.installment_value, 0),
    installment_label: String(product?.installment_label || "").trim(),
    installmentLabel: String(product?.installment_label || "").trim(),
    payment_method_simulated: String(product?.payment_method_simulated || "credit_card").trim(),
    paymentMethodSimulated: String(product?.payment_method_simulated || "credit_card").trim(),
    payment_fee_value:
      product?.payment_fee_value === null || product?.payment_fee_value === undefined
        ? null
        : toNumber(product?.payment_fee_value, 0),
    paymentFeeValue:
      product?.payment_fee_value === null || product?.payment_fee_value === undefined
        ? null
        : toNumber(product?.payment_fee_value, 0),
    payment_net_value:
      product?.payment_net_value === null || product?.payment_net_value === undefined
        ? null
        : toNumber(product?.payment_net_value, 0),
    paymentNetValue:
      product?.payment_net_value === null || product?.payment_net_value === undefined
        ? null
        : toNumber(product?.payment_net_value, 0),
    home_order: toNumber(product?.home_order, 0),
    homeOrder: toNumber(product?.home_order, 0),
    created_at: product?.created_at || null,
    createdAt: product?.created_at || null,
    updated_at: product?.updated_at || null,
    updatedAt: product?.updated_at || null,
    sales_count: toNumber(product?.sales_count ?? product?.total_sales, 0),
    salesCount: toNumber(product?.sales_count ?? product?.total_sales, 0),
    total_sales: toNumber(product?.total_sales ?? product?.sales_count, 0),
    totalSales: toNumber(product?.total_sales ?? product?.sales_count, 0),
    views_count: toNumber(product?.views_count ?? product?.total_views, 0),
    viewsCount: toNumber(product?.views_count ?? product?.total_views, 0),
    margin_percent: toNumber(product?.margin_percent ?? product?.real_margin_percent, 0),
    marginPercent: toNumber(product?.margin_percent ?? product?.real_margin_percent, 0),
    affiliate_commission_percent: toNumber(product?.affiliate_commission_percent, 0),
    affiliateCommissionPercent: toNumber(product?.affiliate_commission_percent, 0),
    pricing_updated_at: product?.pricing_updated_at || null,
    pricingUpdatedAt: product?.pricing_updated_at || null
  };
}

function getMercadoPagoAccessToken() {
  return (
    env.mercadoPagoAccessToken ||
    process.env.MERCADO_PAGO_ACCESS_TOKEN ||
    ""
  ).trim();
}

function getMercadoPagoWebhookSecret() {
  return (
    env.mercadoPagoWebhookSecret ||
    process.env.MERCADO_PAGO_WEBHOOK_SECRET ||
    ""
  ).trim();
}

function getMetaPixelId() {
  return String(
    env.metaPixelId ||
      process.env.META_PIXEL_ID ||
      ""
  ).trim();
}

function getMetaConversionsApiAccessToken() {
  return String(
    env.metaConversionsApiAccessToken ||
      process.env.META_CONVERSIONS_API_ACCESS_TOKEN ||
      ""
  ).trim();
}

function getMetaApiVersion() {
  return String(
    env.metaApiVersion ||
      process.env.META_API_VERSION ||
      "v22.0"
  ).trim();
}

function sha256Normalize(value) {
  const normalized = String(value || "").trim().toLowerCase();
  if (!normalized) return "";
  return crypto.createHash("sha256").update(normalized).digest("hex");
}

function hashPhoneForMeta(value) {
  const digits = onlyDigits(value);
  if (!digits) return "";
  return crypto.createHash("sha256").update(digits).digest("hex");
}

function buildMetaUserData(order) {
  const email = String(order?.customer_email || "").trim().toLowerCase();
  const phone = String(order?.customer_phone || "").trim();
  const firstName = String(order?.customer_name || "")
    .trim()
    .split(/\s+/)
    .filter(Boolean)[0] || "";
  const lastNameParts = String(order?.customer_name || "")
    .trim()
    .split(/\s+/)
    .filter(Boolean);
  const lastName =
    lastNameParts.length > 1 ? lastNameParts[lastNameParts.length - 1] : "";

  const city = String(order?.shipping_city || "").trim().toLowerCase();
  const state = String(order?.shipping_state || "").trim().toLowerCase();
  const zip = onlyDigits(order?.shipping_cep || "");
  const country = "br";

  const userData = {};

  if (email) userData.em = [sha256Normalize(email)];
  if (phone) userData.ph = [hashPhoneForMeta(phone)];
  if (firstName) userData.fn = [sha256Normalize(firstName)];
  if (lastName) userData.ln = [sha256Normalize(lastName)];
  if (city) userData.ct = [sha256Normalize(city)];
  if (state) userData.st = [sha256Normalize(state)];
  if (zip) userData.zp = [sha256Normalize(zip)];
  if (country) userData.country = [sha256Normalize(country)];

  return userData;
}

async function sendMetaPurchaseEvent({ order, items = [], payment }) {
  try {
    const pixelId = getMetaPixelId();
    const accessToken = getMetaConversionsApiAccessToken();
    const apiVersion = getMetaApiVersion();

    if (!pixelId || !accessToken) {
      console.log(
        "META PURCHASE SKIPPED: META_PIXEL_ID ou META_CONVERSIONS_API_ACCESS_TOKEN nÃ£o configurado"
      );
      return {
        sent: false,
        skipped: true,
        reason: "meta_not_configured"
      };
    }

    const totalValue = Number(order?.total_amount || 0) || 0;
    const eventId = `purchase_${String(order?.order_number || "")}_${String(payment?.id || "")}`.trim();

    const payload = {
      data: [
        {
          event_name: "Purchase",
          event_time: Math.floor(Date.now() / 1000),
          action_source: "website",
          event_id: eventId,
          user_data: buildMetaUserData(order),
          custom_data: {
            currency: "BRL",
            value: totalValue,
            order_id: String(order?.order_number || ""),
            content_type: "product",
            content_ids: items
              .map((item) => String(item?.product_id || item?.id || "").trim())
              .filter(Boolean),
            contents: items
              .map((item) => ({
                id: String(item?.product_id || item?.id || "").trim(),
                quantity: Number(item?.quantity || 1) || 1,
                item_price: Number(item?.unit_price || 0) || 0
              }))
              .filter((item) => item.id)
          }
        }
      ]
    };

    if (process.env.META_TEST_EVENT_CODE) {
      payload.test_event_code = String(process.env.META_TEST_EVENT_CODE).trim();
    }

    const url = `https://graph.facebook.com/${apiVersion}/${pixelId}/events?access_token=${encodeURIComponent(accessToken)}`;

    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(payload)
    });

    const data = await response.json().catch(() => ({}));

    if (!response.ok) {
      console.error("ERRO AO ENVIAR PURCHASE PARA META:", data);
      return {
        sent: false,
        skipped: false,
        error: data
      };
    }

    console.log("PURCHASE ENVIADO PARA META COM SUCESSO:", data);

    return {
      sent: true,
      skipped: false,
      response: data
    };
  } catch (error) {
    console.error("ERRO INTERNO AO ENVIAR PURCHASE PARA META:", error);
    return {
      sent: false,
      skipped: false,
      error: error.message || String(error)
    };
  }
}

function getApiBaseUrl(req) {
  const configured = env.apiBaseUrl || process.env.API_BASE_URL || "";

  if (String(configured).trim()) {
    return String(configured).trim().replace(/\/+$/, "");
  }

  const protocol = req.headers["x-forwarded-proto"] || req.protocol || "http";
  const host = req.get("host");

  return `${protocol}://${host}`;
}

function getStoreBackUrls() {
  return {
    success:
      env.storeSuccessUrl ||
      process.env.STORE_SUCCESS_URL ||
      "http://127.0.0.1:5500/frontend/pages-html/pagamento-sucesso.html",
    pending:
      env.storePendingUrl ||
      process.env.STORE_PENDING_URL ||
      "http://127.0.0.1:5500/frontend/pages-html/pagamento-pendente.html",
    failure:
      env.storeFailureUrl ||
      process.env.STORE_FAILURE_URL ||
      "http://127.0.0.1:5500/frontend/pages-html/pagamento-falha.html"
  };
}

function isPaymentSimulationEnabled() {
  if (env.nodeEnv === "production") {
    return false;
  }

  const value =
    env.enablePaymentSimulation ||
    process.env.ENABLE_PAYMENT_SIMULATION ||
    "";

  return ["1", "true", "yes", "on"].includes(
    String(value).trim().toLowerCase()
  );
}

function getFrenetConfig() {
  return {
    token: String(env.frenetToken || process.env.FRENET_TOKEN || "").trim(),
    originZipCode: onlyDigits(
      env.frenetOriginZipCode || process.env.FRENET_ORIGIN_ZIP_CODE || ""
    ),
    quoteUrl: String(
      env.frenetQuoteUrl ||
        process.env.FRENET_QUOTE_URL ||
        "https://api.frenet.com.br/shipping/quote"
    ).trim()
  };
}

function buildShippingPackage(items = []) {
  const totalWeight = items.reduce(
    (acc, item) =>
      acc + Number(item.product.weightKg || 0) * Number(item.quantity || 0),
    0
  );

  const maxHeight = items.reduce(
    (acc, item) => Math.max(acc, Number(item.product.heightCm || 0)),
    0
  );

  const maxWidth = items.reduce(
    (acc, item) => Math.max(acc, Number(item.product.widthCm || 0)),
    0
  );

  const totalLength = items.reduce(
    (acc, item) =>
      acc + Number(item.product.lengthCm || 0) * Number(item.quantity || 0),
    0
  );

  return {
    weightKg: totalWeight > 0 ? Number(totalWeight.toFixed(3)) : 0.3,
    heightCm: maxHeight > 0 ? Number(maxHeight.toFixed(2)) : 16,
    widthCm: maxWidth > 0 ? Number(maxWidth.toFixed(2)) : 8,
    lengthCm: totalLength > 0 ? Number(totalLength.toFixed(2)) : 8
  };
}

function mapFrenetQuotes(raw) {
  const possibleLists = [
    raw?.ShippingSevicesArray,
    raw?.ShippingServicesArray,
    raw?.ShippingServices,
    raw?.shippingServices,
    raw?.services,
    raw?.data,
    raw
  ];

  const list = possibleLists.find((item) => Array.isArray(item)) || [];

  return list
    .map((service) => {
      const price =
        Number(
          service?.ShippingPrice ??
            service?.price ??
            service?.Price ??
            service?.OriginalShippingPrice ??
            service?.ServicePrice ??
            0
        ) || 0;

      const deliveryTime =
        Number(
          service?.DeliveryTime ??
            service?.deliveryTime ??
            service?.DeliveryDays ??
            service?.ShippingDeadline ??
            0
        ) || 0;

      const serviceCode = String(
        service?.ServiceCode ??
          service?.serviceCode ??
          service?.Code ??
          service?.Id ??
          ""
      ).trim();

      const serviceName = String(
        service?.ServiceDescription ??
          service?.ServiceName ??
          service?.serviceName ??
          service?.Description ??
          service?.Name ??
          ""
      ).trim();

      const carrier = String(
        service?.Carrier ??
          service?.CarrierName ??
          service?.carrier ??
          service?.Company ??
          service?.Vendor ??
          "Transportadora"
      ).trim();

      return {
        carrier,
        serviceCode,
        serviceName: serviceName || "ServiÃ§o",
        price,
        deliveryTime,
        raw: service
      };
    })
    .filter((item) => item.price > 0);
}

async function quoteShippingWithFrenet({ zipCode, items, subtotal }) {
  const config = getFrenetConfig();

  if (!config.token) {
    throw new Error("FRENET_TOKEN nÃ£o configurado");
  }

  if (!config.originZipCode) {
    throw new Error("FRENET_ORIGIN_ZIP_CODE nÃ£o configurado");
  }

  const destinationZipCode = onlyDigits(zipCode);

  if (!destinationZipCode || destinationZipCode.length < 8) {
    throw new Error("CEP de destino invÃ¡lido");
  }

  const pkg = buildShippingPackage(items);

  const payload = {
    SellerCEP: config.originZipCode,
    RecipientCEP: destinationZipCode,
    ShipmentInvoiceValue: Number(subtotal || 0),
    ShippingItemArray: [
      {
        Height: pkg.heightCm,
        Length: pkg.lengthCm,
        Width: pkg.widthCm,
        Weight: pkg.weightKg,
        Quantity: 1
      }
    ]
  };

  const response = await fetch(config.quoteUrl, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      token: config.token
    },
    body: JSON.stringify(payload)
  });

  const text = await response.text();
  let data = null;

  try {
    data = text ? JSON.parse(text) : null;
  } catch {
    data = { raw: text };
  }

  if (!response.ok) {
    throw new Error(
      data?.message || data?.error || "Erro ao consultar frete na Frenet"
    );
  }

  const quotes = mapFrenetQuotes(data);

  return {
    quotes,
    raw: data,
    package: pkg
  };
}

async function fetchProductsTable() {
  const url = `${env.supabaseUrl}/rest/v1/products?select=*`;

  const response = await fetch(url, {
    method: "GET",
    headers: {
      apikey: env.supabaseServiceRoleKey,
      Authorization: `Bearer ${env.supabaseServiceRoleKey}`,
      "Content-Type": "application/json",
      Accept: "application/json"
    }
  });

  const text = await response.text();
  let data = [];

  try {
    data = text ? JSON.parse(text) : [];
  } catch {
    data = [];
  }

  return {
    ok: response.ok,
    status: response.status,
    data: Array.isArray(data) ? data : [],
    raw: data
  };
}

function buildHomeProductsSnapshot(rows = []) {
  return rankHomeProducts(
    filterKitChildrenForStorefront(
      rows
        .map(normalizeProduct)
        .filter((product) => {
          const isActive = String(product.status || "").toLowerCase() === "active";
          const hasStock = Number(product.stockQuantity || 0) > 0;
          return product.id && product.name && isActive && hasStock;
        })
    ).filter((product) => product.showOnHome || product.show_on_home || product.showHome)
  ).slice(0, HOME_PRODUCTS_SERVER_CACHE_LIMIT);
}

async function getHomeProductsSnapshot() {
  const now = Date.now();
  const cacheAge = now - Number(homeProductsServerCache.createdAt || 0);

  if (
    homeProductsServerCache.createdAt &&
    cacheAge <= HOME_PRODUCTS_SERVER_CACHE_TTL_MS
  ) {
    return {
      products: homeProductsServerCache.products,
      source: "memory",
    };
  }

  if (!homeProductsLoadPromise) {
    homeProductsLoadPromise = (async () => {
      const response = await fetchProductsTable();

      if (!response.ok) {
        const error = new Error("Erro ao buscar produtos da página inicial");
        error.status = response.status;
        error.details = response.raw;
        throw error;
      }

      const products = buildHomeProductsSnapshot(response.data);

      homeProductsServerCache = {
        createdAt: Date.now(),
        products,
      };

      return {
        products,
        source: "origin",
      };
    })();
  }

  const activeLoadPromise = homeProductsLoadPromise;

  try {
    return await activeLoadPromise;
  } catch (error) {
    const staleAge = Date.now() - Number(homeProductsServerCache.createdAt || 0);

    if (
      homeProductsServerCache.createdAt &&
      staleAge <= HOME_PRODUCTS_SERVER_CACHE_STALE_MS
    ) {
      console.warn("PRODUTOS DA HOME: usando cache temporariamente após falha na origem.", {
        error: error?.message || String(error),
        staleAge,
      });

      return {
        products: homeProductsServerCache.products,
        source: "stale",
      };
    }

    throw error;
  } finally {
    if (homeProductsLoadPromise === activeLoadPromise) {
      homeProductsLoadPromise = null;
    }
  }
}

function buildProductSearchMap(products) {
  const map = new Map();

  products.forEach((product) => {
    const id = String(product.id || "").trim();
    const sku = String(product.sku || "").trim();
    const slug = String(product.slug || "").trim();
    const name = String(product.name || "").trim();
    const slugifiedName = slugify(name);

    if (id) {
      map.set(id, product);
      map.set(slugify(id), product);
    }

    if (sku) {
      map.set(sku, product);
      map.set(slugify(sku), product);
    }

    if (slug) {
      map.set(slug, product);
      map.set(slugify(slug), product);
    }

    if (name) {
      map.set(name, product);
      map.set(slugifiedName, product);
    }
  });

  return map;
}

async function fetchProductsMap() {
  const response = await fetchProductsTable();

  if (!response.ok) {
    throw new Error("Erro ao carregar produtos para validaÃ§Ã£o do pedido");
  }

  const products = response.data
    .map(normalizeProduct)
    .filter((product) => product.id && product.name);

  return buildProductSearchMap(products);
}

function generateOrderNumber() {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, "0");
  const day = String(now.getDate()).padStart(2, "0");
  const randomPart = crypto.randomBytes(12).toString("hex").toUpperCase();
  return `OZT-${year}${month}${day}-${randomPart}`;
}

function createOrderAccessToken() {
  return crypto.randomBytes(32).toString("hex");
}

function hashOrderAccessToken(value) {
  return crypto.createHash("sha256").update(String(value || "")).digest("hex");
}

function isValidOrderAccessToken(req, order = {}) {
  const provided = String(
    req.headers["x-order-access-token"] ||
      req.query?.access_token ||
      req.body?.access_token ||
      req.body?.accessToken ||
      ""
  ).trim();
  const expectedHash = String(order.public_access_token_hash || "").trim();

  if (!provided || !expectedHash) return false;

  const providedHash = hashOrderAccessToken(provided);
  const providedBuffer = Buffer.from(providedHash, "hex");
  const expectedBuffer = Buffer.from(expectedHash, "hex");

  return (
    providedBuffer.length === expectedBuffer.length &&
    crypto.timingSafeEqual(providedBuffer, expectedBuffer)
  );
}

async function hasVerifiedOrderAccess(req, order = {}) {
  if (isValidOrderAccessToken(req, order)) {
    return true;
  }

  const paymentId = String(req.body?.payment_id || req.body?.paymentId || "").trim();
  if (!paymentId) return false;

  if (String(order.payment_reference || "").trim() === paymentId) {
    return true;
  }

  try {
    const payment = await getMercadoPagoPayment(paymentId);
    return String(payment?.external_reference || "").trim() === String(order.order_number || "").trim();
  } catch {
    return false;
  }
}

async function findCustomerIdByEmail(email) {
  const searchUrl = new URL(`${env.supabaseUrl}/rest/v1/customers`);
  searchUrl.searchParams.set("select", "id,email");
  searchUrl.searchParams.set("email", `eq.${email}`);
  searchUrl.searchParams.set("limit", "1");

  const searchResponse = await fetch(searchUrl.toString(), {
    method: "GET",
    headers: {
      apikey: env.supabaseServiceRoleKey,
      Authorization: `Bearer ${env.supabaseServiceRoleKey}`,
      "Content-Type": "application/json",
      Accept: "application/json",
    },
  });

  const searchData = await searchResponse.json().catch(() => []);

  if (!searchResponse.ok) {
    const error = new Error("Erro ao consultar cliente pelo e-mail.");
    error.statusCode = 502;
    error.details = searchData;
    throw error;
  }

  return Array.isArray(searchData) && searchData[0]?.id
    ? searchData[0].id
    : null;
}

async function findOrCreateCustomer(customer) {
  const email = String(customer.email || "").trim().toLowerCase();

  if (!email) {
    const error = new Error("E-mail do cliente é obrigatório.");
    error.statusCode = 400;
    throw error;
  }

  const existingCustomerId = await findCustomerIdByEmail(email);
  if (existingCustomerId) return existingCustomerId;

  const createPayload = {
    full_name: String(customer.nome || "").trim(),
    email,
    phone: String(customer.telefone || "").trim(),
    city: String(customer.cidade || "").trim(),
    state: String(customer.estado || "").trim(),
    origin: "Site",
    status: "lead",
    notes: "",
  };

  const createResponse = await fetch(`${env.supabaseUrl}/rest/v1/customers`, {
    method: "POST",
    headers: {
      apikey: env.supabaseServiceRoleKey,
      Authorization: `Bearer ${env.supabaseServiceRoleKey}`,
      "Content-Type": "application/json",
      Prefer: "return=representation",
    },
    body: JSON.stringify(createPayload),
  });

  const createData = await createResponse.json().catch(() => []);

  if (createResponse.ok && Array.isArray(createData) && createData[0]?.id) {
    return createData[0].id;
  }

  // Duas compras simultâneas podem tentar criar o mesmo e-mail.
  // Após conflito de unicidade, reutiliza o registro criado pela outra requisição.
  const conflictCode = String(createData?.code || "");
  if (createResponse.status === 409 || conflictCode === "23505") {
    const concurrentCustomerId = await findCustomerIdByEmail(email);
    if (concurrentCustomerId) return concurrentCustomerId;
  }

  const error = new Error("Erro ao criar cliente.");
  error.statusCode = createResponse.status >= 400 ? createResponse.status : 500;
  error.details = createData;
  throw error;
}

function parseMercadoPagoSignature(signatureHeader = "") {
  const parts = String(signatureHeader)
    .split(",")
    .map((part) => part.trim())
    .filter(Boolean);

  const values = {};

  for (const part of parts) {
    const [key, value] = part.split("=");
    if (key && value) {
      values[key.trim()] = value.trim();
    }
  }

  return {
    ts: values.ts || "",
    v1: values.v1 || ""
  };
}

function validateMercadoPagoWebhookSignature({
  xSignature,
  xRequestId,
  dataId,
  secret
}) {
  if (!xSignature || !xRequestId || !dataId || !secret) {
    return false;
  }

  const { ts, v1 } = parseMercadoPagoSignature(xSignature);

  if (!ts || !v1) {
    return false;
  }

  const manifest = `id:${dataId};request-id:${xRequestId};ts:${ts};`;

  const generated = crypto
    .createHmac("sha256", secret)
    .update(manifest)
    .digest("hex");

  const generatedBuffer = Buffer.from(generated, "hex");
  const receivedBuffer = Buffer.from(String(v1 || ""), "hex");

  return (
    generatedBuffer.length === receivedBuffer.length &&
    generatedBuffer.length > 0 &&
    crypto.timingSafeEqual(generatedBuffer, receivedBuffer)
  );
}

async function createMercadoPagoPreference({ req, order, items, customer }) {
  const accessToken = getMercadoPagoAccessToken();

  if (!accessToken) {
    throw new Error("MERCADO_PAGO_ACCESS_TOKEN não configurado");
  }

  const apiBaseUrl = getApiBaseUrl(req);
  const backUrls = getStoreBackUrls();

  const preferenceItems = items.map((item) => ({
    id: String(item.product.id || ""),
    title: String(item.product.name || "Produto OZONTECK"),
    quantity: Number(item.quantity || 1),
    unit_price: Number(item.unitPrice || 0),
    currency_id: "BRL"
  }));

  const shippingAmount = Number(order.shipping_amount || 0) || 0;

  if (shippingAmount > 0) {
    preferenceItems.push({
      id: `frete-${String(order.order_number || order.id || "ozonteck")}`,
      title: "Frete",
      quantity: 1,
      unit_price: Number(shippingAmount.toFixed(2)),
      currency_id: "BRL"
    });
  }

  const body = {
    items: preferenceItems,
    external_reference: String(order.order_number || ""),
    notification_url: `${apiBaseUrl}/api/store/payments/mercado-pago/webhook`,
    back_urls: {
      success: backUrls.success,
      pending: backUrls.pending,
      failure: backUrls.failure
    },
    auto_return: "approved",
    payer: {
      name: String(customer.nome || "").trim() || undefined,
      email: String(customer.email || "").trim().toLowerCase() || undefined,
      phone: String(customer.telefone || "").trim()
        ? {
            number: String(customer.telefone || "").replace(/\D/g, "")
          }
        : undefined
    },
    metadata: {
      order_number: String(order.order_number || ""),
      order_id: String(order.id || "")
    }
  };

  const response = await fetch(
    "https://api.mercadopago.com/checkout/preferences",
    {
      method: "POST",
      headers: {
        Authorization: `Bearer ${accessToken}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(body)
    }
  );

  const data = await response.json().catch(() => ({}));

  if (!response.ok || !data?.id) {
    throw new Error(
      data?.message ||
        data?.error ||
        "Erro ao criar preferência de pagamento no Mercado Pago"
    );
  }

  return data;
}


async function getMercadoPagoPayment(paymentId) {
  const accessToken = getMercadoPagoAccessToken();

  if (!accessToken) {
    throw new Error("MERCADO_PAGO_ACCESS_TOKEN nÃ£o configurado");
  }

  const response = await fetch(
    `https://api.mercadopago.com/v1/payments/${paymentId}`,
    {
      method: "GET",
      headers: {
        Authorization: `Bearer ${accessToken}`,
        "Content-Type": "application/json"
      }
    }
  );

  const data = await response.json().catch(() => ({}));

  if (!response.ok || !data?.id) {
    throw new Error(
      data?.message ||
        data?.error ||
        "Erro ao consultar pagamento no Mercado Pago"
    );
  }

  return data;
}


async function createMercadoPagoPixPayment({ req, order, customer }) {
  const accessToken = getMercadoPagoAccessToken();

  if (!accessToken) {
    throw new Error("MERCADO_PAGO_ACCESS_TOKEN não configurado");
  }

  const apiBaseUrl = getApiBaseUrl(req);
  const customerNameParts = String(customer.nome || "").trim().split(/\s+/).filter(Boolean);
  const firstName = customerNameParts.shift() || "Cliente";
  const lastName = customerNameParts.join(" ") || "OZONTECK";
  const cpfDigits = onlyDigits(customer.cpf || "");
  const transactionAmount = Number(Number(order.total_amount || 0).toFixed(2));

  if (!transactionAmount || transactionAmount <= 0) {
    throw new Error("Valor do pedido inválido para gerar Pix.");
  }

  const payer = {
    email: String(customer.email || "").trim().toLowerCase(),
    first_name: firstName,
    last_name: lastName
  };

  if (cpfDigits.length === 11) {
    payer.identification = {
      type: "CPF",
      number: cpfDigits
    };
  }

  const body = {
    transaction_amount: transactionAmount,
    description: `Pedido OZONTECK ${String(order.order_number || "")}`.trim(),
    payment_method_id: "pix",
    external_reference: String(order.order_number || ""),
    notification_url: `${apiBaseUrl}/api/store/payments/mercado-pago/webhook`,
    payer,
    metadata: {
      order_number: String(order.order_number || ""),
      order_id: String(order.id || "")
    }
  };

  const response = await fetch("https://api.mercadopago.com/v1/payments", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": "application/json",
      "X-Idempotency-Key": `ozonteck-pix-${String(order.order_number || order.id || Date.now())}`
    },
    body: JSON.stringify(body)
  });

  const data = await response.json().catch(() => ({}));

  if (!response.ok || !data?.id) {
    throw new Error(
      data?.message ||
        data?.error ||
        data?.cause?.[0]?.description ||
        "Erro ao gerar Pix no Mercado Pago"
    );
  }

  return data;
}


async function createMercadoPagoBoletoPayment({ req, order, customer }) {
  const accessToken = getMercadoPagoAccessToken();

  if (!accessToken) {
    throw new Error("MERCADO_PAGO_ACCESS_TOKEN não configurado");
  }

  const apiBaseUrl = getApiBaseUrl(req);
  const customerNameParts = String(customer.nome || "").trim().split(/\s+/).filter(Boolean);
  const firstName = customerNameParts.shift() || "Cliente";
  const lastName = customerNameParts.join(" ") || "OZONTECK";
  const cpfDigits = onlyDigits(customer.cpf || "");
  const transactionAmount = Number(Number(order.total_amount || 0).toFixed(2));

  if (!transactionAmount || transactionAmount <= 0) {
    throw new Error("Valor do pedido inválido para gerar boleto.");
  }

  if (cpfDigits.length !== 11) {
    throw new Error("CPF válido é obrigatório para gerar boleto.");
  }

  const zipCode = onlyDigits(customer.cep || "");
  const streetName = String(customer.endereco || "").trim();
  const streetNumber = String(customer.numero || "").trim() || "S/N";
  const neighborhood = String(customer.bairro || "").trim();
  const city = String(customer.cidade || "").trim();
  const federalUnit = String(customer.estado || "").trim().toUpperCase().slice(0, 2);

  if (!zipCode || !streetName || !neighborhood || !city || !federalUnit) {
    throw new Error("Endereço completo é obrigatório para gerar boleto.");
  }

  const body = {
    transaction_amount: transactionAmount,
    description: `Pedido OZONTECK ${String(order.order_number || "")}`.trim(),
    payment_method_id: "bolbradesco",
    external_reference: String(order.order_number || ""),
    notification_url: `${apiBaseUrl}/api/store/payments/mercado-pago/webhook`,
    payer: {
      email: String(customer.email || "").trim().toLowerCase(),
      first_name: firstName,
      last_name: lastName,
      identification: {
        type: "CPF",
        number: cpfDigits
      },
      address: {
        zip_code: zipCode,
        street_name: streetName,
        street_number: streetNumber,
        neighborhood,
        city,
        federal_unit: federalUnit
      }
    },
    metadata: {
      order_number: String(order.order_number || ""),
      order_id: String(order.id || "")
    }
  };

  const response = await fetch("https://api.mercadopago.com/v1/payments", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": "application/json",
      "X-Idempotency-Key": `ozonteck-boleto-${String(order.order_number || order.id || Date.now())}`
    },
    body: JSON.stringify(body)
  });

  const data = await response.json().catch(() => ({}));

  if (!response.ok || !data?.id) {
    throw new Error(
      data?.message ||
        data?.error ||
        data?.cause?.[0]?.description ||
        "Erro ao gerar boleto no Mercado Pago"
    );
  }

  return data;
}

async function updateOrderById(orderId, payload) {
  const url = new URL(`${env.supabaseUrl}/rest/v1/orders`);
  url.searchParams.set("id", `eq.${orderId}`);

  const response = await fetch(url.toString(), {
    method: "PATCH",
    headers: {
      apikey: env.supabaseServiceRoleKey,
      Authorization: `Bearer ${env.supabaseServiceRoleKey}`,
      "Content-Type": "application/json",
      Prefer: "return=representation"
    },
    body: JSON.stringify(payload)
  });

  const data = await response.json().catch(() => []);

  return {
    ok: response.ok,
    status: response.status,
    data,
    raw: data
  };
}

async function updateOrderByExternalReference(externalReference, payload) {
  const url = new URL(`${env.supabaseUrl}/rest/v1/orders`);
  url.searchParams.set("payment_external_reference", `eq.${externalReference}`);
  url.searchParams.set("select", "*");

  const response = await fetch(url.toString(), {
    method: "PATCH",
    headers: {
      apikey: env.supabaseServiceRoleKey,
      Authorization: `Bearer ${env.supabaseServiceRoleKey}`,
      "Content-Type": "application/json",
      Prefer: "return=representation"
    },
    body: JSON.stringify(payload)
  });

  const data = await response.json().catch(() => []);

  return {
    ok: response.ok,
    status: response.status,
    data,
    raw: data
  };
}

async function queryOrderByExactField(field, value) {
  const url = new URL(`${env.supabaseUrl}/rest/v1/orders`);
  url.searchParams.set(field, `eq.${value}`);
  url.searchParams.set("select", "*");
  url.searchParams.set("limit", "2");

  const response = await fetch(url.toString(), {
    method: "GET",
    headers: {
      apikey: env.supabaseServiceRoleKey,
      Authorization: `Bearer ${env.supabaseServiceRoleKey}`,
      "Content-Type": "application/json",
      Accept: "application/json",
    },
  });

  const data = await response.json().catch(() => []);

  if (!response.ok) {
    const error = new Error(`Erro ao consultar pedido por ${field}.`);
    error.statusCode = 502;
    error.details = data;
    throw error;
  }

  const orders = Array.isArray(data) ? data : [];
  if (orders.length > 1) {
    const error = new Error(`Mais de um pedido encontrado para ${field}.`);
    error.statusCode = 409;
    error.code = "AMBIGUOUS_ORDER_REFERENCE";
    throw error;
  }

  return orders[0] || null;
}

async function findOrderByExternalReference(externalReference) {
  const cleanReference = String(externalReference || "").trim();

  if (!cleanReference) {
    const error = new Error("Referência externa do pedido ausente.");
    error.statusCode = 400;
    throw error;
  }

  const byGatewayReference = await queryOrderByExactField(
    "payment_external_reference",
    cleanReference
  );
  if (byGatewayReference) return byGatewayReference;

  // O webhook pode chegar antes de a preferência/pagamento ser persistido no pedido.
  const byOrderNumber = await queryOrderByExactField("order_number", cleanReference);
  if (byOrderNumber) return byOrderNumber;

  const error = new Error("Pedido não encontrado pela referência externa.");
  error.statusCode = 404;
  throw error;
}

async function findOrderItems(orderId) {
  const url = new URL(`${env.supabaseUrl}/rest/v1/order_items`);
  url.searchParams.set("order_id", `eq.${orderId}`);
  url.searchParams.set("select", "*");

  const response = await fetch(url.toString(), {
    method: "GET",
    headers: {
      apikey: env.supabaseServiceRoleKey,
      Authorization: `Bearer ${env.supabaseServiceRoleKey}`,
      "Content-Type": "application/json",
      Accept: "application/json"
    }
  });

  const data = await response.json().catch(() => []);

  if (!response.ok) {
    throw new Error("Erro ao buscar itens do pedido");
  }

  return Array.isArray(data) ? data : [];
}

function getShippingProvider() {
  return String(process.env.SHIPPING_PROVIDER || "").trim().toLowerCase();
}

function getStoreOriginZipCode() {
  return onlyDigits(
    process.env.MELHOR_ENVIO_ORIGIN_ZIP_CODE ||
      process.env.MELHOR_ENVIO_FROM_POSTAL_CODE ||
      process.env.MELHOR_ENVIO_POSTAL_CODE ||
      process.env.STORE_ORIGIN_ZIP_CODE ||
      env.frenetOriginZipCode ||
      process.env.FRENET_ORIGIN_ZIP_CODE ||
      process.env.ORIGIN_ZIP_CODE ||
      ""
  );
}

function normalizeMelhorEnvioProducts(items = []) {
  return items.map((item, index) => {
    const product = item.product || {};
    const quantity = Number(item.quantity || 1) || 1;

    const width = Math.max(1, Number(product.widthCm || 0) || 1);
    const height = Math.max(1, Number(product.heightCm || 0) || 1);
    const length = Math.max(1, Number(product.lengthCm || 0) || 1);
    const weight = Math.max(0.001, Number(product.weightKg || 0) || 0.3);
    const insuranceValue = Math.max(
      0,
      Number(product.price || item.unitPrice || 0) || 0
    );

    return {
      id: String(product.id || product.sku || `item-${index + 1}`),
      width,
      height,
      length,
      weight,
      insurance_value: insuranceValue,
      quantity
    };
  });
}

function mapMelhorEnvioQuotes(services = []) {
  return services
    .filter((service) => !service?.error)
    .map((service) => {
      const companyName = String(
        service?.company?.name ||
          service?.company?.company_name ||
          "Transportadora"
      ).trim();

      const serviceName = String(service?.name || "ServiÃ§o").trim();
      const serviceCode = String(service?.id || "").trim();
      const price = Number(service?.price || 0) || 0;

      const deliveryTime =
        Number(
          service?.delivery_time ||
            service?.custom_delivery_time ||
            service?.packages?.[0]?.delivery_time ||
            0
        ) || 0;

      return {
        carrier: companyName,
        serviceCode,
        serviceName,
        price,
        deliveryTime,
        raw: service
      };
    })
    .filter((item) => item.price > 0);
}

async function quoteShippingWithMelhorEnvio({ zipCode, items }) {
  const originZipCode = getStoreOriginZipCode();
  const destinationZipCode = onlyDigits(zipCode);

  if (!originZipCode || originZipCode.length < 8) {
    throw new Error("CEP de origem da loja nÃ£o configurado");
  }

  if (!destinationZipCode || destinationZipCode.length < 8) {
    throw new Error("CEP de destino invÃ¡lido");
  }

  const products = normalizeMelhorEnvioProducts(items);

  const payload = {
    from: {
      postal_code: originZipCode
    },
    to: {
      postal_code: destinationZipCode
    },
    products,
    options: {
      receipt: false,
      own_hand: false,
      collect: false
    }
  };

  const rawServices = await calculateShippingWithMelhorEnvio(payload);
  const quotes = mapMelhorEnvioQuotes(rawServices);

  return {
    quotes,
    raw: rawServices,
    payload
  };
}

function resolveSelectedShippingServiceCode(selectedShipping = {}) {
  const direct = String(selectedShipping?.serviceCode || "").trim();
  const directNumber = Number(direct);

  if (Number.isFinite(directNumber) && directNumber > 0) {
    return String(directNumber);
  }

  const raw = selectedShipping?.raw || {};
  const candidates = [
    raw?.id,
    raw?.Id,
    raw?.serviceCode,
    raw?.service_code,
    raw?.ServiceCode,
    raw?.Code
  ]
    .map((value) => String(value || "").trim())
    .filter(Boolean);

  for (const candidate of candidates) {
    const numeric = Number(candidate);
    if (Number.isFinite(numeric) && numeric > 0) {
      return String(numeric);
    }
  }

  return direct;
}

async function validateSelectedShippingQuote({
  zipCode,
  items,
  subtotal,
  selectedShipping
}) {
  const selectedServiceCode = resolveSelectedShippingServiceCode(selectedShipping);
  const selectedPrice = Number(selectedShipping?.price || 0) || 0;

  if (!selectedServiceCode) {
    throw new Error("ServiÃ§o de frete nÃ£o selecionado");
  }

  if (selectedPrice <= 0) {
    throw new Error("Valor de frete invÃ¡lido");
  }

  const provider = getShippingProvider();

  const result =
    provider === "melhor_envio"
      ? await quoteShippingWithMelhorEnvio({ zipCode, items })
      : await quoteShippingWithFrenet({ zipCode, items, subtotal });

  const quotes = Array.isArray(result.quotes) ? result.quotes : [];

  const matchedQuote = quotes.find((quote) => {
    const quoteCode = String(quote.serviceCode || "").trim();
    return quoteCode === String(selectedServiceCode || "").trim();
  });

  if (!matchedQuote) {
    throw new Error("ServiÃ§o de frete invÃ¡lido ou expirado");
  }

  const realPrice = Number(matchedQuote.price || 0) || 0;

  if (realPrice <= 0) {
    throw new Error("Valor real de frete invÃ¡lido");
  }

  const priceDifference = Math.abs(realPrice - selectedPrice);

  if (priceDifference > 0.05) {
    throw new Error("Valor de frete divergente. Recalcule o frete.");
  }

  return {
    provider,
    quote: matchedQuote,
    raw: result.raw || null
  };
}

function buildShippingQuoteRawForOrder(selectedShipping = {}) {
  const raw = selectedShipping?.raw || null;

  return {
    ...(raw && typeof raw === "object" ? raw : {}),
    selected_service_code_front: String(selectedShipping?.serviceCode || "").trim(),
    selected_service_name_front: String(selectedShipping?.serviceName || "").trim(),
    selected_carrier_front: String(selectedShipping?.carrier || "").trim(),
    selected_price_front: Number(selectedShipping?.price || 0) || 0,
    selected_delivery_time_front:
      Number(selectedShipping?.deliveryTime || 0) || 0
  };
}

function normalizeShippingLabelStatusForSave(labelData = {}) {
  const status = String(labelData?.labelStatus || "").trim().toLowerCase();
  const hasShipmentId = String(labelData?.shipmentId || "").trim();

  if (status === "cart_created") {
    return "awaiting_shipping_label";
  }

  if (status) {
    return status;
  }

  if (labelData?.success) {
    return hasShipmentId ? "awaiting_shipping_label" : "generated";
  }

  return "error";
}

function hasShippingLabelSuccessData(labelData = {}) {
  return Boolean(
    labelData?.success &&
      (
        String(labelData?.labelUrl || "").trim() ||
        String(labelData?.labelPdfUrl || "").trim() ||
        String(labelData?.trackingCode || "").trim() ||
        String(labelData?.shipmentId || "").trim() ||
        ["awaiting_shipping_label", "cart_created"].includes(
          String(labelData?.labelStatus || "").trim().toLowerCase()
        )
      )
  );
}

function isShippingLabelInProgressOrDone(status) {
  return ["awaiting_shipping_label", "cart_created", "generated", "shipped", "posted", "delivered"]
    .includes(String(status || "").trim().toLowerCase());
}

async function saveGeneratedLabel(orderId, labelData = {}) {
  const success = hasShippingLabelSuccessData(labelData);
  const labelStatus = success ? normalizeShippingLabelStatusForSave(labelData) : (labelData?.labelStatus || "error");
  const labelError = success ? "" : String(labelData?.error || labelData?.raw?.reason || "Erro ao gerar etiqueta").trim();
  const trackingCode = String(labelData?.trackingCode || "").trim();
  const labelUrl = String(labelData?.labelUrl || "").trim();
  const labelPdfUrl = String(labelData?.labelPdfUrl || "").trim();
  const shipmentId = String(labelData?.shipmentId || "").trim();

  const patch = {
    shipping_label_status: labelStatus,
    shipping_label_error: labelError,
    shipping_label_raw: labelData?.raw || null,
    shipping_label_processing_started_at: null,
    processed_at: new Date().toISOString()
  };

  if (labelUrl) patch.shipping_label_url = labelUrl;
  if (labelPdfUrl) patch.shipping_label_pdf_url = labelPdfUrl;
  if (trackingCode) {
    patch.shipping_tracking_code = trackingCode;
    patch.tracking_code = trackingCode;
  }
  if (shipmentId) patch.shipping_shipment_id = shipmentId;
  if (success && labelStatus === "generated") {
    patch.shipping_label_generated_at = new Date().toISOString();
  }

  return updateOrderById(orderId, patch);
}

async function saveLabelError(orderId, errorMessage) {
  return updateOrderById(orderId, {
    shipping_label_status: "error",
    shipping_label_error: String(errorMessage || "Erro ao gerar etiqueta"),
    shipping_label_generated_at: null,
    shipping_label_processing_started_at: null
  });
}



router.get("/notifications/vapid-public-key", async (req, res) => {
  try {
    const publicKey = getCustomerOrderPushPublicKey();

    if (!publicKey) {
      return res.status(500).json({
        success: false,
        message: "Chave pública de notificação não configurada"
      });
    }

    return res.status(200).json({
      success: true,
      publicKey
    });
  } catch (error) {
    console.error("ERRO AO BUSCAR CHAVE PÚBLICA DE PUSH DO CLIENTE:", error);

    return res.status(500).json({
      success: false,
      message: error.message || "Erro ao buscar configuração de notificação"
    });
  }
});

router.post("/orders/:orderNumber/notifications/subscribe", async (req, res) => {
  try {
    const orderNumber = String(req.params.orderNumber || "").trim();
    const subscription = req.body?.subscription;

    if (!orderNumber) {
      return res.status(400).json({
        success: false,
        message: "Número do pedido é obrigatório"
      });
    }

    if (!subscription?.endpoint || !subscription?.keys?.p256dh || !subscription?.keys?.auth) {
      return res.status(400).json({
        success: false,
        message: "Inscrição de notificação inválida"
      });
    }

    const order = await findOrderByExternalReference(orderNumber).catch(() => null);

    if (!order?.id) {
      return res.status(404).json({
        success: false,
        message: "Pedido não encontrado para ativar notificações"
      });
    }

    const verifiedAccess = await hasVerifiedOrderAccess(req, order);

    if (!verifiedAccess) {
      return res.status(403).json({
        success: false,
        message: "Não foi possível confirmar que este pedido pertence a você.",
      });
    }

    const saved = await saveCustomerOrderPushSubscription({
      orderNumber,
      paymentId: req.body?.payment_id || req.body?.paymentId || "",
      subscription,
      userAgent: req.body?.user_agent || req.headers["user-agent"] || ""
    });

    const orderIsPaid = ["paid", "approved", "pago", "aprovado"].includes(
      String(order.payment_status || "").trim().toLowerCase()
    );
    const testPush = orderIsPaid
      ? await safeCustomerOrderPush(
          "customer_order_push_subscribed",
          order,
          (currentOrder) => sendCustomerOrderPushForPaymentApproved(currentOrder)
        )
      : { sent: false, skipped: true, reason: "payment_not_approved_yet" };

    return res.status(200).json({
      success: true,
      message: "Notificações do pedido ativadas com sucesso",
      subscription: saved,
      testPush
    });
  } catch (error) {
    console.error("ERRO AO SALVAR INSCRIÇÃO DE PUSH DO CLIENTE:", error);

    return res.status(500).json({
      success: false,
      message: error.message || "Erro ao ativar notificações do pedido"
    });
  }
});

router.get("/affiliate-storefront/:slug", async (req, res) => {
  try {
    const result = await getPublicAffiliateStorefront(req.params.slug);

    res.set("Cache-Control", "no-store");

    return res.status(200).json({
      success: true,
      ...result,
    });
  } catch (error) {
    const statusCode = error.statusCode || 500;

    console.error("ERRO AO BUSCAR LOJA DO AFILIADO:", error);

    return res.status(statusCode).json({
      success: false,
      message: error.message || "Erro interno ao buscar loja do afiliado",
    });
  }
});

router.get("/products/home", async (req, res) => {
  try {
    const limit = Math.max(1, Math.min(24, Number(req.query.limit || 8) || 8));
    const snapshot = await getHomeProductsSnapshot();
    const products = snapshot.products.slice(0, limit);

    res.set("Cache-Control", "public, max-age=30, stale-while-revalidate=300");
    res.set("X-Ozonteck-Home-Cache", snapshot.source);

    return res.status(200).json({
      success: true,
      products
    });
  } catch (error) {
    console.error("ERRO AO LISTAR PRODUTOS DA HOME:", error);

    return res.status(500).json({
      success: false,
      message: "Erro interno ao listar produtos da página inicial",
      details: String(error?.message || error)
    });
  }
});

router.get("/products", async (req, res) => {
  try {
    const response = await fetchProductsTable();

    if (!response.ok) {
      return res.status(500).json({
        success: false,
        message: "Erro ao buscar produtos da loja",
        details: response.raw
      });
    }

    const products = rankStorefrontProducts(
      response.data
        .map(normalizeProduct)
        .filter((product) => product.id && product.name)
    );

    return res.status(200).json({
      success: true,
      products
    });

  } catch (error) {
    console.error("ERRO AO LISTAR PRODUTOS DA LOJA:", error);

    return res.status(500).json({
      success: false,
      message: "Erro interno ao listar produtos da loja",
      details: String(error?.message || error)
    });
  }
});

router.get("/products/:ref", async (req, res) => {
  try {
    const rawRef = String(req.params.ref || "").trim();

    const response = await fetchProductsTable();

    if (!response.ok) {
      return res.status(500).json({
        success: false,
        message: "Erro ao buscar produto da loja",
        details: response.raw
      });
    }

    const products = response.data
      .map(normalizeProduct)
      .filter((product) => product.id && product.name);

    const map = buildProductSearchMap(products);
    const product = map.get(rawRef) || map.get(slugify(rawRef)) || null;

    if (!product) {
      return res.status(404).json({
        success: false,
        message: "Produto nÃ£o encontrado"
      });
    }

    return res.status(200).json({
      success: true,
      product
    });
  } catch (error) {
    console.error("ERRO AO BUSCAR PRODUTO DA LOJA:", error);

    return res.status(500).json({
      success: false,
      message: "Erro interno ao buscar produto da loja",
      details: String(error?.message || error)
    });
  }
});

router.post("/shipping/quote", async (req, res) => {
  try {
    const body = req.body || {};
    const zipCode = String(body.zipCode || body.cep || "").trim();
    const items = Array.isArray(body.items) ? body.items : [];

    if (!zipCode) {
      return res.status(400).json({
        success: false,
        message: "CEP Ã© obrigatÃ³rio"
      });
    }

    if (!items.length) {
      return res.status(400).json({
        success: false,
        message: "Itens do carrinho sÃ£o obrigatÃ³rios"
      });
    }

    const productsMap = await fetchProductsMap();

    const normalizedItems = items.map((item) => {
      const ref = String(
        item.id || item.slug || item.sku || item.nome || ""
      ).trim();

      const normalizedRef = slugify(ref);
      const quantity = normalizeItemQuantity(
        item.quantity ?? item.quantidade ?? 1
      );

      const product = productsMap.get(ref) || productsMap.get(normalizedRef);

      if (!product) {
        throw new Error(
          `Produto invÃ¡lido no pedido: ${ref || "sem referÃªncia"}`
        );
      }

      return {
        product,
        quantity,
        unitPrice: roundMoney(product.price || 0),
        totalPrice: roundMoney(roundMoney(product.price || 0) * quantity)
      };
    });

    const subtotal = roundMoney(
      normalizedItems.reduce((acc, item) => acc + item.totalPrice, 0)
    );

    const provider = getShippingProvider();

    if (provider === "melhor_envio") {
      const result = await quoteShippingWithMelhorEnvio({
        zipCode,
        items: normalizedItems
      });

      return res.status(200).json({
        success: true,
        provider: "melhor_envio",
        quotes: result.quotes,
        raw: result.raw
      });
    }

    const result = await quoteShippingWithFrenet({
      zipCode,
      items: normalizedItems,
      subtotal
    });

    return res.status(200).json({
      success: true,
      provider: "frenet",
      quotes: result.quotes,
      raw: result.raw
    });
  } catch (error) {
    console.error("ERRO AO COTAR FRETE:", error);

    return res.status(Number(error?.status) || 500).json({
      success: false,
      message: error.message || "Erro interno ao cotar frete"
    });
  }
});

router.post("/orders", async (req, res) => {
  try {
    const body = req.body || {};
    const customer = body.customer || {};
    const items = Array.isArray(body.items) ? body.items : [];
    const notes = String(body.notes || "").trim();
    const affiliateRef = normalizeAffiliateCode(body.affiliateRef || body.affiliate_ref || "");
    const affiliate = await findActiveAffiliateByRef(affiliateRef);

    if (!customer.nome || !customer.email || !customer.telefone) {
      return res.status(400).json({
        success: false,
        message: "Nome, e-mail e telefone sÃ£o obrigatÃ³rios"
      });
    }

    if (!items.length) {
      return res.status(400).json({
        success: false,
        message: "O pedido precisa ter pelo menos 1 item"
      });
    }

    const productsMap = await fetchProductsMap();

    const normalizedItems = items.map((item) => {
      const ref = String(
        item.id || item.slug || item.sku || item.nome || ""
      ).trim();
      const normalizedRef = slugify(ref);
      const quantity = normalizeItemQuantity(
        item.quantity ?? item.quantidade ?? 1
      );
      const product = productsMap.get(ref) || productsMap.get(normalizedRef);

      if (!product) {
        throw new Error(
          `Produto invÃ¡lido no pedido: ${ref || "sem referÃªncia"}`
        );
      }

      return {
        product,
        quantity,
        unitPrice: roundMoney(product.price || 0),
        totalPrice: roundMoney(roundMoney(product.price || 0) * quantity)
      };
    });

    const subtotal = roundMoney(
      normalizedItems.reduce((acc, item) => acc + item.totalPrice, 0)
    );

        const selectedShipping = body.shipping || {};

    const validatedShipping = await validateSelectedShippingQuote({
      zipCode: customer.cep,
      items: normalizedItems,
      subtotal,
      selectedShipping
    });

    const validatedShippingQuote = validatedShipping.quote;

    const resolvedShippingServiceCode = String(
      validatedShippingQuote.serviceCode || ""
    ).trim();

    const shippingAmount = roundMoney(validatedShippingQuote.price || 0);

    // SeguranÃ§a: nÃ£o aceitar desconto vindo direto do frontend.
    // Quando houver cupom, validar o cupom no backend antes de aplicar desconto.
    const discountAmount = 0;

    const totalAmount = roundMoney(subtotal + shippingAmount - discountAmount);

    const productPricingMap = await fetchProductPricingMap(
      normalizedItems.map((item) => item.product.id)
    );
    const orderCostSnapshot = buildOrderCostSnapshot(
      normalizedItems,
      productPricingMap
    );
    const orderCommissionPolicy = calculateCommissionPolicyFromCartItems({
      items: normalizedItems,
      discountAmount,
      fallbackSellerRate: affiliate?.commission_rate || 0,
      fallbackRecruitmentRate: getRecruitmentCommissionRate(affiliate || {}),
      pricingMap: productPricingMap,
    });



    await findOrCreateCustomer(customer);
    const orderNumber = generateOrderNumber();
    const orderAccessToken = createOrderAccessToken();

    const orderPayload = {
      order_number: orderNumber,
      customer_name: String(customer.nome || "").trim(),
      customer_email: String(customer.email || "").trim().toLowerCase(),
      customer_phone: String(customer.telefone || "").trim(),
      customer_cpf: String(customer.cpf || "").trim(),
      shipping_cep: String(customer.cep || "").trim(),
      shipping_address: String(customer.endereco || "").trim(),
      shipping_number: String(customer.numero || "").trim(),
      shipping_complement: String(customer.complemento || "").trim(),
      shipping_neighborhood: String(customer.bairro || "").trim(),
      shipping_city: String(customer.cidade || "").trim(),
      shipping_state: String(customer.estado || "").trim(),
      shipping_carrier: String(selectedShipping.carrier || "").trim(),
      shipping_service_code: String(resolvedShippingServiceCode || "").trim(),
      shipping_service_name: String(selectedShipping.serviceName || "").trim(),
      shipping_delivery_time: Number(selectedShipping.deliveryTime || 0) || null,
      shipping_quote_raw: buildShippingQuoteRawForOrder(selectedShipping),
      shipping_label_status: "pending",
      subtotal,
      shipping_amount: shippingAmount,
      discount_amount: discountAmount,
      total_amount: totalAmount,

      affiliate_id: affiliate?.id || null,
      affiliate_ref_code: affiliate?.ref_code || affiliateRef || "",
      affiliate_coupon_code: affiliate?.coupon_code || "",
      affiliate_commission_rate: affiliate?.id
        ? orderCommissionPolicy.sellerRate
        : null,
      affiliate_commission_amount: affiliate?.id
        ? orderCommissionPolicy.sellerCommissionAmount
        : null,

      product_cost: orderCostSnapshot.totals.productCost,
      ad_cost: orderCostSnapshot.totals.trafficCost,
      other_costs: roundMoney(
        orderCostSnapshot.totals.packagingCost +
          orderCostSnapshot.totals.operationalCost +
          orderCostSnapshot.totals.otherCost
      ),
      financial_snapshot: {
        version: 1,
        captured_at: new Date().toISOString(),
        product_cost: orderCostSnapshot.totals.productCost,
        packaging_cost: orderCostSnapshot.totals.packagingCost,
        traffic_cost: orderCostSnapshot.totals.trafficCost,
        operational_cost: orderCostSnapshot.totals.operationalCost,
        other_cost: orderCostSnapshot.totals.otherCost,
        embedded_shipping_estimate:
          orderCostSnapshot.totals.embeddedShippingEstimate,
        base_cost_total: orderCostSnapshot.totals.totalCost,
        items_without_pricing: orderCostSnapshot.totals.itemsWithoutPricing,
        seller_commission_amount: affiliate?.id
          ? orderCommissionPolicy.sellerCommissionAmount
          : 0,
        network_commission_estimate: affiliate?.id
          ? orderCommissionPolicy.recruitmentCommissionAmount
          : 0,
      },

      payment_status: "pending",
      order_status: "pending",
      tracking_code: "",
      notes,
      public_access_token_hash: hashOrderAccessToken(orderAccessToken)
    };

    const orderItemsPayload = orderCostSnapshot.items.map((item) => ({
      product_id: item.product.id,
      product_name: item.product.name,
      sku: item.product.sku || "",
      quantity: item.quantity,
      unit_price: item.unitPrice,
      total_price: item.totalPrice,
      unit_product_cost: item.costSnapshot.unitProductCost,
      unit_packaging_cost: item.costSnapshot.unitPackagingCost,
      unit_traffic_cost: item.costSnapshot.unitTrafficCost,
      unit_operational_cost: item.costSnapshot.unitOperationalCost,
      unit_other_cost: item.costSnapshot.unitOtherCost,
      unit_total_cost: item.costSnapshot.unitTotalCost,
      total_cost: item.costSnapshot.totalCost,
      pricing_snapshot: item.costSnapshot,
    }));

    let atomicOrderResult;

    try {
      atomicOrderResult = await createStoreOrderAtomic(orderPayload, orderItemsPayload);
    } catch (atomicError) {
      const detailsText = JSON.stringify(atomicError?.details || {});
      const messageText = `${atomicError?.message || ""} ${detailsText}`;

      if (messageText.includes("INSUFFICIENT_STOCK")) {
        return res.status(409).json({
          success: false,
          message: "Um dos produtos ficou sem estoque durante a compra. Atualize o carrinho e tente novamente.",
          code: "INSUFFICIENT_STOCK",
        });
      }

      if (messageText.includes("PRODUCT_INACTIVE") || messageText.includes("PRODUCT_NOT_FOUND")) {
        return res.status(409).json({
          success: false,
          message: "Um dos produtos não está mais disponível. Atualize o carrinho.",
          code: "PRODUCT_UNAVAILABLE",
        });
      }

      console.error("ATOMIC ORDER CREATION ERROR:", atomicError?.details || atomicError);
      return res.status(503).json({
        success: false,
        message: "Não foi possível reservar os produtos. Confirme se sql/security-integrity-hardening.sql foi aplicado no Supabase.",
        code: "ATOMIC_ORDER_UNAVAILABLE",
      });
    }

    const createdOrder = atomicOrderResult?.order;
    const itemsData = Array.isArray(atomicOrderResult?.items)
      ? atomicOrderResult.items
      : [];

    if (!createdOrder?.id || !itemsData.length) {
      return res.status(500).json({
        success: false,
        message: "O pedido não foi concluído com segurança.",
        code: "ATOMIC_ORDER_INVALID_RESULT",
      });
    }

    try {
      await notifyOrderCreatedPending(createdOrder);
    } catch (notificationError) {
      console.error("ERRO AO ENVIAR NOTIFICAÇÃO DE PEDIDO PENDENTE:", notificationError);
    }


   if (isPaymentSimulationEnabled()) {
  const simulatedPaymentUrl = new URL(
    "https://ozonteck-loja.onrender.com/pages-html/pagamento-simulado.html"
  );

  simulatedPaymentUrl.searchParams.set(
    "external_reference",
    String(createdOrder.order_number || "")
  );

  simulatedPaymentUrl.searchParams.set(
    "order_number",
    String(createdOrder.order_number || "")
  );

  return res.status(201).json({
    success: true,
    message: "Pedido criado com sucesso. Aguardando pagamento simulado.",
    order: {
      id: createdOrder.id,
      number: createdOrder.order_number,
      total: totalAmount,
      status: createdOrder.order_status,
      paymentStatus: createdOrder.payment_status,
      accessToken: orderAccessToken
    },
    payment: {
      gateway: "simulation_page",
      preferenceId: "",
      paymentUrl: simulatedPaymentUrl.toString(),
      sandboxPaymentUrl: simulatedPaymentUrl.toString(),
      externalReference: createdOrder.order_number
    }
  });
}

const accessToken = getMercadoPagoAccessToken();

if (!accessToken) {
  try {
    await releaseOrderStock(createdOrder.id, "payment_gateway_not_configured");
  } catch (stockReleaseError) {
    console.error("ERRO AO DEVOLVER ESTOQUE SEM GATEWAY CONFIGURADO:", stockReleaseError);
  }

  return res.status(500).json({
    success: false,
    message:
      "MERCADO_PAGO_ACCESS_TOKEN não configurado. Ative ENABLE_PAYMENT_SIMULATION=true apenas fora de produção."
  });
}

const requestedPaymentMethod = String(
  body.paymentMethod || body.payment_method || "gateway_redirect"
)
  .trim()
  .toLowerCase();

if (requestedPaymentMethod === "pix_transparent") {
  const pixPayment = await createMercadoPagoPixPayment({
    req,
    order: createdOrder,
    customer
  });

  const transactionData = pixPayment?.point_of_interaction?.transaction_data || {};

  const paymentUpdate = await updateOrderById(createdOrder.id, {
    payment_gateway: "mercado_pago_pix",
    payment_reference: String(pixPayment.id || ""),
    payment_external_reference: String(createdOrder.order_number || ""),
    payment_raw_status: String(pixPayment.status || "pending"),
    payment_status: "pending"
  });

  if (!paymentUpdate.ok) {
    return res.status(500).json({
      success: false,
      message: "Pedido criado, mas houve erro ao salvar a referência do Pix",
      details: paymentUpdate.raw
    });
  }

  return res.status(201).json({
    success: true,
    message: "Pedido criado com sucesso. Pix gerado para pagamento.",
    order: {
      id: createdOrder.id,
      number: createdOrder.order_number,
      total: totalAmount,
      status: createdOrder.order_status,
      paymentStatus: "pending",
      accessToken: orderAccessToken
    },
    payment: {
      gateway: "mercado_pago_pix",
      method: "pix",
      paymentId: pixPayment.id,
      externalReference: createdOrder.order_number,
      status: pixPayment.status || "pending",
      statusDetail: pixPayment.status_detail || "",
      qrCode: transactionData.qr_code || "",
      qrCodeBase64: transactionData.qr_code_base64 || "",
      ticketUrl: transactionData.ticket_url || "",
      expiresAt: transactionData.date_of_expiration || pixPayment.date_of_expiration || ""
    }
  });
}


if (requestedPaymentMethod === "boleto_transparent") {
  const boletoPayment = await createMercadoPagoBoletoPayment({
    req,
    order: createdOrder,
    customer
  });

  const transactionDetails = boletoPayment?.transaction_details || {};
  const paymentUpdate = await updateOrderById(createdOrder.id, {
    payment_gateway: "mercado_pago_boleto",
    payment_reference: String(boletoPayment.id || ""),
    payment_external_reference: String(createdOrder.order_number || ""),
    payment_raw_status: String(boletoPayment.status || "pending"),
    payment_status: "pending"
  });

  if (!paymentUpdate.ok) {
    return res.status(500).json({
      success: false,
      message: "Pedido criado, mas houve erro ao salvar a referência do boleto",
      details: paymentUpdate.raw
    });
  }

  return res.status(201).json({
    success: true,
    message: "Pedido criado com sucesso. Boleto gerado para pagamento.",
    order: {
      id: createdOrder.id,
      number: createdOrder.order_number,
      total: totalAmount,
      status: createdOrder.order_status,
      paymentStatus: "pending",
      accessToken: orderAccessToken
    },
    payment: {
      gateway: "mercado_pago_boleto",
      method: "boleto",
      paymentId: boletoPayment.id,
      externalReference: createdOrder.order_number,
      status: boletoPayment.status || "pending",
      statusDetail: boletoPayment.status_detail || "",
      ticketUrl: transactionDetails.external_resource_url || boletoPayment.transaction_details?.external_resource_url || "",
      barcode: transactionDetails.barcode || "",
      digitableLine: transactionDetails.digitable_line || transactionDetails.line || "",
      paymentMethodId: boletoPayment.payment_method_id || "bolbradesco",
      dateOfExpiration: boletoPayment.date_of_expiration || ""
    }
  });
}


    const preference = await createMercadoPagoPreference({
      req,
      order: createdOrder,
      items: normalizedItems,
      customer
    });

    const paymentUpdate = await updateOrderById(createdOrder.id, {
      payment_gateway: "mercado_pago",
      payment_reference: String(preference.id || ""),
      payment_external_reference: String(createdOrder.order_number || ""),
      payment_raw_status: "preference_created"
    });

    if (!paymentUpdate.ok) {
      return res.status(500).json({
        success: false,
        message:
          "Pedido criado, mas houve erro ao salvar a referÃªncia de pagamento",
        details: paymentUpdate.raw
      });
    }

    return res.status(201).json({
      success: true,
      message: "Pedido criado com sucesso",
      order: {
        id: createdOrder.id,
        number: createdOrder.order_number,
        total: totalAmount,
        status: createdOrder.order_status,
        paymentStatus: createdOrder.payment_status,
        accessToken: orderAccessToken
      },
      payment: {
        gateway: "mercado_pago",
        preferenceId: preference.id,
        paymentUrl: preference.init_point || "",
        sandboxPaymentUrl: preference.sandbox_init_point || "",
        externalReference: createdOrder.order_number
      }
    });
  } catch (error) {
    console.error("ERRO AO CRIAR PEDIDO DA LOJA:", error);

    return res.status(Number(error?.status) || 500).json({
      success: false,
      message: error.message || "Erro interno ao criar pedido"
    });
  }
});

router.post("/payments/mercado-pago/webhook", async (req, res) => {
  try {
    const topic = String(
      req.body?.type ||
        req.query?.type ||
        req.body?.topic ||
        req.query?.topic ||
        ""
    ).trim();

    const dataId = String(
      req.body?.data?.id ||
        req.body?.id ||
        req.query?.["data.id"] ||
        req.query?.id ||
        ""
    ).trim();

    if (!dataId) {
      return res.status(200).json({
        success: true,
        received: true,
        ignored: true,
        reason: "missing_data_id"
      });
    }

    const secret = getMercadoPagoWebhookSecret();
    const xSignature = String(req.headers["x-signature"] || "").trim();
    const xRequestId = String(req.headers["x-request-id"] || "").trim();

    if (env.nodeEnv === "production" && !secret) {
      console.error("WEBHOOK MERCADO PAGO: MERCADO_PAGO_WEBHOOK_SECRET ausente em produção.");
      return res.status(503).json({
        success: false,
        message: "Webhook de pagamento temporariamente indisponível.",
      });
    }

    if (secret) {
      const hasSignatureHeaders = Boolean(xSignature && xRequestId);

      if (hasSignatureHeaders) {
        const isValid = validateMercadoPagoWebhookSignature({
          xSignature,
          xRequestId,
          dataId,
          secret
        });

        if (!isValid) {
          console.warn(
            "WEBHOOK MERCADO PAGO: assinatura inválida; continuando com validação do pagamento diretamente na API do Mercado Pago.",
            { dataId, topic }
          );
        }
      } else {
        console.warn(
          "WEBHOOK MERCADO PAGO: assinatura ausente (possível IPN legado); continuando com validação do pagamento diretamente na API do Mercado Pago.",
          { dataId, topic }
        );
      }
    }

    if (topic !== "payment") {
      return res.status(200).json({
        success: true,
        received: true,
        ignored: true,
        topic
      });
    }

    const payment = await getMercadoPagoPayment(dataId);
    const externalReference = String(payment?.external_reference || "").trim();
    const paymentStatus = String(payment?.status || "").trim().toLowerCase();
    const paymentFinancialData = getMercadoPagoFinancialData(payment);

    if (!externalReference) {
      return res.status(200).json({
        success: true,
        received: true,
        ignored: true,
        reason: "missing_external_reference"
      });
    }

    let previousOrder = null;

    try {
      previousOrder = await findOrderByExternalReference(externalReference);
    } catch (previousOrderError) {
      console.warn(
        "NÃƒO FOI POSSÃVEL BUSCAR ESTADO ANTERIOR DO PEDIDO ANTES DO UPDATE:",
        previousOrderError.message || previousOrderError
      );
    }

    if (!previousOrder?.id) {
      return res.status(200).json({
        success: true,
        received: true,
        ignored: true,
        reason: "order_not_found",
      });
    }

    const expectedAmount = Number(previousOrder.total_amount || 0);
    const receivedAmount = Number(payment?.transaction_amount || 0);
    const currencyId = String(payment?.currency_id || "BRL").trim().toUpperCase();
    const metadataOrderId = String(payment?.metadata?.order_id || "").trim();
    const amountMatches =
      Number.isFinite(expectedAmount) &&
      Number.isFinite(receivedAmount) &&
      Math.abs(expectedAmount - receivedAmount) <= 0.01;
    const identityMatches = !metadataOrderId || metadataOrderId === String(previousOrder.id);

    if (!amountMatches || currencyId !== "BRL" || !identityMatches) {
      console.error("WEBHOOK MERCADO PAGO: divergência financeira ou de identidade.", {
        orderId: previousOrder.id,
        externalReference,
        expectedAmount,
        receivedAmount,
        currencyId,
        metadataOrderId,
      });

      await updateOrderById(previousOrder.id, {
        payment_raw_status: "review_required",
        payment_status: "review_required",
        webhook_last_event: "payment_validation_failed",
        notes: `${String(previousOrder.notes || "")}
Pagamento ${String(payment.id || "")} exige revisão: valor, moeda ou vínculo divergente.`.trim(),
      });

      return res.status(200).json({
        success: true,
        received: true,
        reviewRequired: true,
        reason: "payment_validation_failed",
      });
    }

    if (paymentStatus === "approved") {
      const stockReservation = await ensureOrderStockReserved(previousOrder.id);

      if (!stockReservation?.reserved) {
        await updateOrderById(previousOrder.id, {
          payment_raw_status: "approved_stock_review",
          payment_status: "review_required",
          order_status: "stock_review",
          webhook_last_event: "payment_stock_unavailable",
        });

        console.error("PAGAMENTO APROVADO SEM ESTOQUE DISPONÍVEL:", {
          orderId: previousOrder.id,
          orderNumber: previousOrder.order_number,
          paymentId: payment.id,
          stockReservation,
        });

        return res.status(200).json({
          success: true,
          received: true,
          reviewRequired: true,
          reason: "approved_payment_without_stock",
        });
      }
    }

    const transition = await applyMercadoPagoPaymentTransition({
      externalReference,
      paymentId: payment.id,
      rawStatus: paymentStatus,
      gatewayFee: paymentFinancialData.gatewayFee,
      netAmount: paymentFinancialData.netAmount,
      paymentMethodId: paymentFinancialData.paymentMethodId || null,
      paymentTypeId: paymentFinancialData.paymentTypeId || null,
      installments: paymentFinancialData.installments,
    });

    if (!transition?.success) {
      return res.status(200).json({
        success: true,
        received: true,
        ignored: true,
        reason: transition?.reason || "payment_transition_not_applied",
      });
    }

    const isFirstPaymentTransition = Boolean(transition.claimed);

    if (!isFirstPaymentTransition && paymentStatus !== "approved") {
      return res.status(200).json({
        success: true,
        received: true,
        duplicate: true,
        reason: transition.reason || "already_processed",
      });
    }

    const updateResponse = {
      ok: true,
      status: 200,
      data: transition.order ? [transition.order] : [],
      raw: transition,
    };

    let labelResult = null;
    let metaPurchaseResult = null;
    let affiliateConversionResult = null;
    let activationOfferResult = null;
    let customerPaymentPushResult = null;
    let customerTrackingPushResult = null;

    if (paymentStatus === "approved") {
      try {
        const updatedOrder =
          Array.isArray(updateResponse.data) && updateResponse.data[0]
            ? updateResponse.data[0]
            : await findOrderByExternalReference(externalReference);

        const orderItems = await findOrderItems(updatedOrder.id);


        activationOfferResult = await createActivationOfferSafely(
  updatedOrder,
  "mercado_pago_webhook"
);

try {
          // A criação possui consulta prévia e constraint única no banco.
          // Em reentrega do webhook, isto também reconcilia uma comissão que tenha faltado
          // após uma falha entre a transição do pagamento e os efeitos posteriores.
          affiliateConversionResult = await createAffiliateConversionForPaidOrder(updatedOrder);
        } catch (affiliateError) {
          console.error("ERRO AO CRIAR/RECONCILIAR COMISSÃO DO AFILIADO:", affiliateError);

          affiliateConversionResult = {
            created: false,
            skipped: false,
            error: affiliateError.message || "Erro ao criar comissão do afiliado",
          };
        }

        if (isFirstPaymentTransition) {
          metaPurchaseResult = await sendMetaPurchaseEvent({
            order: updatedOrder,
            items: orderItems,
            payment
          });

          try {
            await notifyOrderPaid(updatedOrder);
          } catch (notificationError) {
            console.error("ERRO AO ENVIAR NOTIFICAÇÃO DE PEDIDO PAGO:", notificationError);
          }

          customerPaymentPushResult = await safeCustomerOrderPush(
            "payment_approved",
            updatedOrder,
            (currentOrder) => sendCustomerOrderPushForPaymentApproved(currentOrder)
          );
        } else {
          metaPurchaseResult = {
            sent: false,
            skipped: true,
            reason: "payment_transition_already_processed"
          };
        }

        const labelClaim = await claimOrderShippingLabelGeneration(updatedOrder.id);

        if (labelClaim?.claimed) {
          const generatedLabel = await generateAutomaticShippingLabel(
            updatedOrder,
            orderItems,
            { claimAlreadyAcquired: true }
          );

          const savedLabel = await saveGeneratedLabel(
            updatedOrder.id,
            generatedLabel
          );

          if (!savedLabel.ok) {
            throw new Error("Erro ao salvar dados da etiqueta no pedido");
          }

          const labelSavedSuccessfully = hasShippingLabelSuccessData(generatedLabel);
          const labelSavedStatus = labelSavedSuccessfully
            ? normalizeShippingLabelStatusForSave(generatedLabel)
            : generatedLabel?.labelStatus || "error";
          const generatedTrackingCode = String(generatedLabel?.trackingCode || "").trim();

          if (labelSavedSuccessfully && generatedTrackingCode) {
            const refreshedShippingOrder = {
              ...updatedOrder,
              shipping_label_status: labelSavedStatus,
              shipping_label_url: String(generatedLabel.labelUrl || ""),
              shipping_label_pdf_url: String(generatedLabel.labelPdfUrl || ""),
              shipping_tracking_code: generatedTrackingCode,
              shipping_shipment_id: String(generatedLabel.shipmentId || ""),
              tracking_code: generatedTrackingCode
            };

            customerTrackingPushResult = await safeCustomerOrderPush(
              "tracking_available",
              refreshedShippingOrder,
              (currentOrder) => sendCustomerOrderPushForTracking(currentOrder)
            );
          } else {
            customerTrackingPushResult = {
              sent: false,
              skipped: true,
              reason: labelSavedSuccessfully ? "tracking_not_available_yet" : "shipping_label_error"
            };
          }

          labelResult = {
            generated: labelSavedSuccessfully,
            status: labelSavedStatus,
            trackingCode: generatedLabel.trackingCode,
            shipmentId: generatedLabel.shipmentId,
            error: generatedLabel.error || ""
          };
        } else {
          labelResult = {
            generated: false,
            reason: labelClaim?.reason || "label_already_in_progress_or_done"
          };
        }
      } catch (labelError) {
        console.error("ERRO AO GERAR ETIQUETA AUTOMÃTICA:", labelError);

        const refreshedOrder =
          Array.isArray(updateResponse.data) && updateResponse.data[0]
            ? updateResponse.data[0]
            : null;

        if (refreshedOrder?.id) {
          await saveLabelError(
            refreshedOrder.id,
            labelError.message || "Erro ao gerar etiqueta"
          );
        }

        labelResult = {
          generated: false,
          error: labelError.message || "Erro ao gerar etiqueta"
        };
      }
    }

    if (["rejected", "cancelled", "refunded", "charged_back"].includes(paymentStatus)) {
      const failedOrder = transition.order || previousOrder;

      try {
        await syncAffiliateCommissionLifecycleForOrder(
          failedOrder,
          `mercado_pago_${paymentStatus}`
        );
      } catch (lifecycleError) {
        console.error("ERRO AO REVERTER CICLO DE COMISSÃO APÓS FALHA/ESTORNO:", lifecycleError);
      }

      const previousShippingStatus = String(previousOrder.order_status || "").trim().toLowerCase();
      const canReturnReservedStock =
        ["rejected", "cancelled", "refunded", "charged_back"].includes(paymentStatus) &&
        !["shipped", "enviado", "delivered", "entregue"].includes(previousShippingStatus) &&
        !String(previousOrder.tracking_code || previousOrder.shipping_tracking_code || "").trim();

      if (canReturnReservedStock) {
        try {
          await releaseOrderStock(previousOrder.id, `mercado_pago_${paymentStatus}`);
        } catch (stockReleaseError) {
          console.error("ERRO AO DEVOLVER ESTOQUE DO PEDIDO CANCELADO/ESTORNADO:", stockReleaseError);
        }
      }

      try {
        await notifyOrderPaymentFailed(failedOrder);
      } catch (notificationError) {
        console.error("ERRO AO NOTIFICAR FALHA/ESTORNO DO PAGAMENTO:", notificationError);
      }
    }

   return res.status(200).json({
  success: true,
  message: "Webhook Mercado Pago processado com sucesso",
  received: true,
  paymentStatus,
  externalReference,
  label: labelResult,
  metaPurchase: metaPurchaseResult,
  affiliateConversion: affiliateConversionResult,
  activationOffer: activationOfferResult,
  customerPaymentPush: customerPaymentPushResult,
  customerTrackingPush: customerTrackingPushResult
});
  } catch (error) {
    console.error("ERRO NO WEBHOOK DO MERCADO PAGO:", error);

    return res.status(500).json({
      success: false,
      message: error.message || "Erro interno no webhook"
    });
  }
});

router.post("/payments/simulate/:orderNumber", requireAdminAuth, requireMasterAdmin, async (req, res) => {
  try {
    if (!isPaymentSimulationEnabled()) {
      return res.status(403).json({
        success: false,
        message: "SimulaÃ§Ã£o de pagamento desativada"
      });
    }

    const orderNumber = String(req.params.orderNumber || "").trim();
    const status = String(req.body?.status || "approved")
      .trim()
      .toLowerCase();

    if (!orderNumber) {
      return res.status(400).json({
        success: false,
        message: "NÃºmero do pedido Ã© obrigatÃ³rio"
      });
    }

    let previousOrder = null;

    try {
      previousOrder = await findOrderByExternalReference(orderNumber);
    } catch (previousOrderError) {
      console.warn(
        "NÃƒO FOI POSSÃVEL BUSCAR ESTADO ANTERIOR DO PEDIDO ANTES DA SIMULAÃ‡ÃƒO:",
        previousOrderError.message || previousOrderError
      );
    }

    const updatePayload = {
      payment_gateway: "simulation",
      payment_external_reference: orderNumber,
      webhook_last_event: "simulation"
    };

    if (status === "approved" || status === "paid") {
      updatePayload.payment_status = "paid";
      updatePayload.payment_raw_status = "approved";
      updatePayload.paid_at = new Date().toISOString();
      updatePayload.order_status = "paid";
    } else if (status === "pending") {
      updatePayload.payment_status = "pending";
      updatePayload.payment_raw_status = "pending";

  } else if (status === "failed" || status === "rejected" || status === "cancelled") {
  updatePayload.payment_status = "pending";
  updatePayload.payment_raw_status = status === "cancelled" ? "cancelled" : "rejected";
  updatePayload.order_status = "pending";
} else {

      return res.status(400).json({
        success: false,
        message: "Status invÃ¡lido para simulaÃ§Ã£o"
      });
    }

    const directOrderUpdate = await updateOrderByExternalReference(
      orderNumber,
      updatePayload
    );

    if (
      directOrderUpdate.ok &&
      Array.isArray(directOrderUpdate.data) &&
      directOrderUpdate.data.length
    ) {
      const updatedOrder = directOrderUpdate.data[0];
        let metaPurchaseResult = null;
        let affiliateConversionResult = null;
        let activationOfferResult = null;

      if ((status === "approved" || status === "paid") && updatedOrder?.id) {
        try {
          const orderItems = await findOrderItems(updatedOrder.id);

          const alreadyPaidBeforeSimulation =
            String(previousOrder?.payment_status || "").trim().toLowerCase() === "paid";

          if (!alreadyPaidBeforeSimulation) {
  try {
  affiliateConversionResult = await createAffiliateConversionForPaidOrder(updatedOrder);
} catch (affiliateError) {
  console.error("ERRO AO CRIAR COMISSÃO DO AFILIADO NA SIMULAÇÃO:", affiliateError);

  affiliateConversionResult = {
    created: false,
    skipped: false,
    error: affiliateError.message || "Erro ao criar comissão do afiliado na simulação",
  };
}

activationOfferResult = await createActivationOfferSafely(
  updatedOrder,
  "payment_simulation"
);

metaPurchaseResult = await sendMetaPurchaseEvent({
    order: updatedOrder,
    items: orderItems,
    payment: {
      id: `simulation_${updatedOrder.order_number}`
    }
  });

  try {
    await notifyOrderPaid(updatedOrder);
  } catch (notificationError) {
    console.error("ERRO AO ENVIAR NOTIFICAÇÃO DE PEDIDO PAGO NA SIMULAÇÃO:", notificationError);
  }
} else {

  affiliateConversionResult = {
    created: false,
    skipped: true,
    reason: "already_paid_before_simulation"
  };

  metaPurchaseResult = {
    sent: false,
    skipped: true,
    reason: "already_paid_before_simulation"
  };
}

          if (!isShippingLabelInProgressOrDone(updatedOrder.shipping_label_status)) {
            const generatedLabel = await generateAutomaticShippingLabel(
              updatedOrder,
              orderItems
            );
            await saveGeneratedLabel(updatedOrder.id, generatedLabel);
          }
        } catch (labelError) {
          console.error("ERRO AO GERAR ETIQUETA NA SIMULAÃ‡ÃƒO:", labelError);
          await saveLabelError(
            updatedOrder.id,
            labelError.message || "Erro ao gerar etiqueta na simulaÃ§Ã£o"
          );
        }
      }

     return res.status(200).json({
  success: true,
  message: "Pagamento simulado com sucesso",
  order: updatedOrder,
  metaPurchase: metaPurchaseResult,
  affiliateConversion: affiliateConversionResult,
  activationOffer: activationOfferResult
});
    }

    const findUrl = new URL(`${env.supabaseUrl}/rest/v1/orders`);
    findUrl.searchParams.set("order_number", `eq.${orderNumber}`);
    findUrl.searchParams.set("select", "id,order_number,shipping_label_status,payment_status");
    findUrl.searchParams.set("limit", "1");

    const findResponse = await fetch(findUrl.toString(), {
      method: "GET",
      headers: {
        apikey: env.supabaseServiceRoleKey,
        Authorization: `Bearer ${env.supabaseServiceRoleKey}`,
        "Content-Type": "application/json",
        Accept: "application/json"
      }
    });

    const findData = await findResponse.json().catch(() => []);

    if (!findResponse.ok || !Array.isArray(findData) || !findData[0]?.id) {
      return res.status(404).json({
        success: false,
        message: "Pedido nÃ£o encontrado para simulaÃ§Ã£o",
        details: findData
      });
    }

    const fallbackUpdate = await updateOrderById(findData[0].id, updatePayload);

    if (
      !fallbackUpdate.ok ||
      !Array.isArray(fallbackUpdate.data) ||
      !fallbackUpdate.data.length
    ) {
      return res.status(500).json({
        success: false,
        message: "Erro ao atualizar pedido na simulaÃ§Ã£o",
        details: fallbackUpdate.raw
      });
    }

    const updatedOrder = fallbackUpdate.data[0];
    let metaPurchaseResult = null;
    let affiliateConversionResult = null;
    let activationOfferResult = null;


        async function notifySimulationPaymentStatus(order) {
      try {
        if (status === "approved" || status === "paid") {
          await notifyOrderPaid(order);
          return;
        }

        if (status === "pending") {
          await notifyOrderPaymentPending(order);
          return;
        }

        if (status === "failed" || status === "rejected" || status === "cancelled") {
          await notifyOrderPaymentFailed(order);
        }
      } catch (notificationError) {
        console.error("ERRO AO ENVIAR NOTIFICAÇÃO DE STATUS DE PAGAMENTO NA SIMULAÇÃO:", notificationError);
      }
    }

    if ((status === "approved" || status === "paid") && updatedOrder?.id) {
      try {
        const orderItems = await findOrderItems(updatedOrder.id);

          activationOfferResult = await createActivationOfferSafely(
            updatedOrder,
            "payment_simulation_fallback"
          );


    const alreadyPaidBeforeSimulation =
  String(previousOrder?.payment_status || "").trim().toLowerCase() === "paid";

activationOfferResult = await createActivationOfferSafely(
  updatedOrder,
  "payment_simulation"
);

if (!alreadyPaidBeforeSimulation) {
  try {
    affiliateConversionResult = await createAffiliateConversionForPaidOrder(updatedOrder);
  } catch (affiliateError) {
    console.error("ERRO AO CRIAR COMISSÃO DO AFILIADO NA SIMULAÇÃO:", affiliateError);

    affiliateConversionResult = {
      created: false,
      skipped: false,
      error: affiliateError.message || "Erro ao criar comissão do afiliado na simulação",
    };
  }

  metaPurchaseResult = await sendMetaPurchaseEvent({
    order: updatedOrder,
    items: orderItems,
    payment: {
      id: `simulation_${updatedOrder.order_number}`
    }
  });

  try {
    await notifyOrderPaid(updatedOrder);
  } catch (notificationError) {
    console.error("ERRO AO ENVIAR NOTIFICAÇÃO DE PEDIDO PAGO NA SIMULAÇÃO:", notificationError);
  }
} else {

  affiliateConversionResult = {
    created: false,
    skipped: true,
    reason: "already_paid_before_simulation"
  };

  metaPurchaseResult = {
    sent: false,
    skipped: true,
    reason: "already_paid_before_simulation"
  };
}

        if (!isShippingLabelInProgressOrDone(updatedOrder.shipping_label_status)) {
          const generatedLabel = await generateAutomaticShippingLabel(
            updatedOrder,
            orderItems
          );
          await saveGeneratedLabel(updatedOrder.id, generatedLabel);
        }
      } catch (labelError) {
        console.error(
          "ERRO AO GERAR ETIQUETA NO FALLBACK DA SIMULAÃ‡ÃƒO:",
          labelError
        );
        await saveLabelError(
          updatedOrder.id,
          labelError.message || "Erro ao gerar etiqueta na simulaÃ§Ã£o"
        );
      }
    }

    if (status === "pending" || status === "failed" || status === "rejected" || status === "cancelled") {
      await notifySimulationPaymentStatus(updatedOrder);
    }


    return res.status(200).json({
  success: true,
  message: "Pagamento simulado com sucesso",
  order: updatedOrder,
  metaPurchase: metaPurchaseResult,
  affiliateConversion: affiliateConversionResult,
  activationOffer: activationOfferResult
});
  } catch (error) {
    console.error("ERRO AO SIMULAR PAGAMENTO:", error);

    return res.status(500).json({
      success: false,
      message: error.message || "Erro interno ao simular pagamento"
    });
  }
});

router.get("/orders/:orderNumber/status", async (req, res) => {
  try {
    const orderNumber = String(req.params.orderNumber || "").trim();

    if (!orderNumber) {
      return res.status(400).json({
        success: false,
        message: "NÃºmero do pedido Ã© obrigatÃ³rio"
      });
    }

    const url = new URL(`${env.supabaseUrl}/rest/v1/orders`);
    url.searchParams.set("order_number", `eq.${orderNumber}`);
    url.searchParams.set(
      "select",
      "order_number,payment_status,order_status,tracking_code,shipping_tracking_code,paid_at,shipping_label_status,shipping_label_generated_at,shipping_service_name"
    );
    url.searchParams.set("limit", "1");

    const response = await fetch(url.toString(), {
      method: "GET",
      headers: {
        apikey: env.supabaseServiceRoleKey,
        Authorization: `Bearer ${env.supabaseServiceRoleKey}`,
        "Content-Type": "application/json",
        Accept: "application/json"
      }
    });

    const data = await response.json().catch(() => []);

    if (!response.ok) {
      return res.status(500).json({
        success: false,
        message: "Erro ao consultar status do pedido"
      });
    }

    if (!Array.isArray(data) || !data[0]) {
      return res.status(404).json({
        success: false,
        message: "Pedido nÃ£o encontrado"
      });
    }

    return res.status(200).json({
      success: true,
      order: data[0]
    });
  } catch (error) {
    console.error("ERRO AO CONSULTAR STATUS DO PEDIDO:", error);

    return res.status(500).json({
      success: false,
      message: error.message || "Erro interno ao consultar status do pedido"
    });
  }
});

router.post("/orders/:id/process-paid", requireAdminAuth, requireMasterAdmin, async (req, res) => {
  try {
    const result = await processPaidOrder({ orderId: req.params.id });

    return res.status(200).json({
      success: true,
      result
    });
  } catch (error) {
    console.error("PROCESS PAID ORDER ERROR:", error);

    return res.status(Number(error?.statusCode || 500)).json({
      success: false,
      message: error.message || "Erro ao processar pedido pago",
      details: error?.details || null,
    });
  }
});

router.get("/melhor-envio/authorize-url", requireAdminAuth, requireMasterAdmin, async (req, res) => {
  try {
    return res.status(200).json({
      success: true,
      url: buildMelhorEnvioAuthorizeUrl(
        await createIntegrationOAuthState({
          provider: "melhor_envio",
          adminId: req.admin?.id,
        })
      )
    });
  } catch (error) {
    console.error("ERRO AO GERAR URL DE AUTORIZAÃ‡ÃƒO DO MELHOR ENVIO:", error);

    return res.status(500).json({
      success: false,
      message: error.message || "Erro ao gerar URL de autorizaÃ§Ã£o"
    });
  }
});

router.post("/affiliates/apply", async (req, res) => {
  try {
    const result = await createAffiliateApplication(req.body || {});

    if (result.alreadyExists) {
      return res.status(200).json({
        success: true,
        alreadyExists: true,
        message:
          "VocÃª jÃ¡ possui uma solicitaÃ§Ã£o de afiliado pendente. Aguarde a anÃ¡lise da equipe OZONTECK.",
        application: result.application,
      });
    }

    return res.status(201).json({
      success: true,
      alreadyExists: false,
      message:
        "SolicitaÃ§Ã£o enviada com sucesso. Nossa equipe vai analisar seu cadastro de afiliado.",
      application: result.application,
    });
  } catch (error) {
    console.error("ERRO AO CRIAR SOLICITAÃ‡ÃƒO DE AFILIADO:", error);

    return res.status(400).json({
      success: false,
      message: error.message || "Erro ao enviar solicitaÃ§Ã£o de afiliado.",
    });
  }
});

router.get("/health", async (req, res) => {
  return res.status(200).json({
    success: true,
    message: "Camada pÃºblica da loja ativa"
  });
});

export default router;

