import { Router } from "express";
import { requireAdminAuth } from "../middlewares/auth.middleware.js";
import { getAiContext } from "../controllers/ai.controller.js";

const router = Router();

router.get(
  "/context",
  requireAdminAuth,
  getAiContext
);

export default router;