// stock.routes.js
