// sales-report-template.js
