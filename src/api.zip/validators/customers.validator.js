// customers.validator.js
