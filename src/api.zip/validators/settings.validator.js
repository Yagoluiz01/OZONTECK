// settings.validator.js
