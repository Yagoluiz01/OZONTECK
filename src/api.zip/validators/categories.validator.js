// categories.validator.js
