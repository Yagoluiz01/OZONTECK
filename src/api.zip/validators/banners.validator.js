// banners.validator.js
