// stock.validator.js
