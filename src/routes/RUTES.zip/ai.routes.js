import { Router } from "express";
import { getAiContext } from "../controllers/ai.controller.js";

const router = Router();

router.get("/context", getAiContext);

export default router;
